import { useStore } from '../store';
import { prepareMotorsForPlayback, startBakedMotorPlayback } from './motor';
import { toast } from '../ui/ui-store';
import { hardwareOutputsEnabled } from './outputGate';

/** Start playback and turn this display into the passenger TV for scenario 08. */
export async function playWithFinalMonitor() {
  const s = useStore.getState();
  if (s.seq.id === '08_exhibition_final' && s.tSec > 0.001) s.setTime(0);
  // Preview playback must remain fully functional without an Arduino. The TV
  // compositor, simulated ring and eyes are browser outputs; only gate on
  // motor preparation after the user explicitly enables physical hardware.
  if (!hardwareOutputsEnabled()) {
    useStore.getState().play();
    return;
  }
  // Do not advance the scenario clock while the real robot is still moving to
  // frame zero (scenario 08 starts at a deliberate +90-degree side pose).
  const ready = await prepareMotorsForPlayback();
  if (!ready) {
    toast('모터 준비 실패: 연결, 출력 잠금, 토크 및 모터 오류를 확인하세요. 영상은 시작하지 않았습니다.', 'warn', 8000);
    return;
  }
  const started = await startBakedMotorPlayback();
  if (!started) {
    toast('아두이노 내장 모션 시작 명령이 실패했습니다. 영상은 시작하지 않았습니다.', 'warn', 8000);
    return;
  }
  useStore.getState().play();
}
