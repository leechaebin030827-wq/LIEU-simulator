import { useStore } from '../store';
import { BODY_MOTOR, followStep, TILT_MOTOR, YAW_MOTOR, type Limits } from '../engine/motorPlan';
import { hardwareOutputsEnabled, subscribeHardwareOutputs } from './outputGate';
import { getU2D2MotorStatus, getU2D2Status, sendU2D2Goals, sendU2D2MotorCommand } from './u2d2';
import { evaluateSequenceAt } from '../engine/evaluate';

/** Motor client for the U2D2. Arduino's independent USB link drives eyes/ring. */
export type Axis = 'yaw' | 'tilt' | 'body';
export type MotorStatus = { ok: boolean; error?: string; detail?: string; torque?: boolean; mode?: number; profile_ok?: boolean; deg?: number | null; hw_error?: number; fault?: string | null; follow?: boolean; needs_front?: boolean; searching?: boolean; limit_deg?: number; max_vel?: number; axes?: Record<Axis, MotorStatus> };
const listeners = new Set<() => void>();
let status: MotorStatus = { ok: false, error: 'Arduino not connected' };
let pollUsers = 0;
let poll = 0, bridgeUp = false, inflight = false, bakedPlayback = false, bakedTimer = 0;
type FollowState = { run: number; timer: number; approaching: boolean; lastSent: number; lastSentAt: number };
const freshFollow = (): FollowState => ({ run: 0, timer: 0, approaching: false, lastSent: NaN, lastSentAt: 0 });
const follow: Record<Axis, FollowState> = { yaw: freshFollow(), tilt: freshFollow(), body: freshFollow() };
const LIMITS: Record<Axis, Limits> = { yaw: YAW_MOTOR, tilt: TILT_MOTOR, body: BODY_MOTOR };

/** Status of one axis (the yaw fields also remain at the top level for UI compatibility). */
export const getMotorStatus = (axis: Axis = 'yaw'): MotorStatus => status.axes?.[axis] ?? (axis === 'yaw' ? status : { ok: false, error: `${axis} motor not reported by Arduino` });
export const motorBridgeUp = () => bridgeUp;
export const subscribeMotor = (f: () => void) => { listeners.add(f); return () => { listeners.delete(f); }; };
const emit = () => listeners.forEach((f) => f());

async function call(path: string, body?: object): Promise<MotorStatus> {
  const safetyAction = path === '/hold' || path === '/release';
  if (body !== undefined && !safetyAction && !hardwareOutputsEnabled()) return { ok: false, error: 'hardware outputs are locked' };
  const b = (body ?? {}) as { axis?: Axis; deg?: number; follow?: boolean };
  const axis = b.axis ?? 'yaw';
  const name = path.slice(1) as 'arm' | 'hold' | 'release' | 'clear' | 'setup' | 'goal' | 'status';
  const readbacks: Partial<Record<Axis, MotorStatus>> = {};
  if (name === 'status') {
    // Keep UNO R4 Wi-Fi replies small and deterministic: one compact status line per axis.
    for (const a of ['yaw', 'tilt', 'body'] as Axis[]) readbacks[a] = await sendU2D2MotorCommand('status', a);
  } else {
    const result = await sendU2D2MotorCommand(name, axis, b.deg ?? 0, b.follow ?? false);
    if (!result.ok) return result;
  }
  const one = (a: Axis): MotorStatus => {
    const m = readbacks[a] ?? getU2D2MotorStatus(a), lim = LIMITS[a];
    return { ...m, max_vel: lim.maxVel, limit_deg: lim.limitDeg };
  };
  const axes = { yaw: one('yaw'), tilt: one('tilt'), body: one('body') };
  return { ...axes[axis], axes };
}

export async function refreshMotor(force = false) {
  // A status read is five DYNAMIXEL transactions per axis. During playback it
  // competes with position goals and repeatedly interrupts the servos' motion
  // profiles, so status is refreshed before/after playback instead.
  if (!force && useStore.getState().playing) return;
  if (inflight) return; // one poll at a time: slow answers must not pile up
  inflight = true;
  const s = await call('/status').finally(() => { inflight = false; });
  bridgeUp = getU2D2Status().connected;
  status = s; emit();
}
// Status uses three round trips on the same link as motion. Four polls per
// second starved the 30 Hz goal stream; one per second is ample for the UI and
// leaves the control channel smooth.
export function startMotorPolling() { pollUsers++; if (!poll) { void refreshMotor(); poll = window.setInterval(() => void refreshMotor(), 1000); } }
export function stopMotorPolling() { pollUsers = Math.max(0, pollUsers - 1); if (!pollUsers) { window.clearInterval(poll); poll = 0; } }

export async function motorAct(name: 'arm' | 'hold' | 'release' | 'clear' | 'setup', axis: Axis = 'yaw') {
  if (name !== 'arm') stopFollow(axis);
  const r = await call('/' + name, { axis });
  await refreshMotor();
  return r;
}
export async function motorGoto(deg: number, axis: Axis = 'yaw') { stopFollow(axis); const r = await call('/goal', { axis, deg, follow: false }); await refreshMotor(); return r; }

export const isFollowing = (axis: Axis = 'yaw') => follow[axis].timer !== 0 || follow[axis].approaching;
export function stopFollow(axis: Axis = 'yaw') {
  const f = follow[axis];
  f.run++;
  const wasActive = f.approaching || f.timer !== 0;
  f.approaching = false;
  if (f.timer) { window.clearInterval(f.timer); f.timer = 0; }
  if (wasActive) void call('/hold', { axis });
  emit();
}

function cancelFollowWithoutHold(axis: Axis) {
  const f = follow[axis];
  f.run++;
  f.approaching = false;
  if (f.timer) { window.clearInterval(f.timer); f.timer = 0; }
}

/** Move every linked axis to the current timeline pose before the clock starts. */
export async function prepareMotorsForPlayback(): Promise<boolean> {
  if (!hardwareOutputsEnabled() || !getU2D2Status().connected) return false;
  const axes = ['yaw', 'tilt', 'body'] as Axis[];
  if (useStore.getState().seq.id === '08_exhibition_final') {
    // Never decide whether the real robot is ready from a possibly stale UI
    // cache. Re-establish the complete motor state on every performance start.
    axes.forEach(cancelFollowWithoutHold);
    for (const axis of axes) {
      const cleared = await call('/clear', { axis });
      if (!cleared.ok) return false;
      await new Promise((resolve) => setTimeout(resolve, 120));
      const armed = await call('/arm', { axis });
      if (!armed.ok) return false;
      await new Promise((resolve) => setTimeout(resolve, 180));
    }

    // Scenario 08 intentionally opens looking 90 degrees to the side. Move to
    // that exact first frame before starting the firmware-resident trajectory.
    const targets: Record<Axis, number> = {
      yaw: clampDeg('yaw', wantNow('yaw')),
      tilt: clampDeg('tilt', wantNow('tilt')),
      body: clampDeg('body', wantNow('body')),
    };
    for (const axis of axes) {
      const moved = await call('/goal', { axis, deg: targets[axis], follow: false });
      if (!moved.ok) return false;
      await new Promise((resolve) => setTimeout(resolve, 80));
    }

    const deadline = performance.now() + 30000;
    while (performance.now() < deadline) {
      await refreshMotor(true);
      const ready = axes.every((axis) => {
        const m = getMotorStatus(axis);
        return !!m.ok && !!m.torque && m.mode === 4 && !!m.profile_ok && !m.fault &&
          m.deg != null && Math.abs(m.deg - targets[axis]) < 1.5;
      });
      if (ready) return true;
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
    return false;
  }

  // An armed axis is a real playback axis even if the UI follower toggle is
  // currently off. Requiring the toggle made video/lights play while all three
  // motors simply held the opening pose.
  const ready = axes.filter((axis) => {
    const m = getMotorStatus(axis);
    return isFollowing(axis) || (!!m.torque && m.mode === 4 && !!m.profile_ok && !m.fault);
  });
  for (const axis of ready) cancelFollowWithoutHold(axis);
  await Promise.all(ready.map((axis) => startFollow(axis)));
  return true;
}

/** Scenario 08 follows the browser clock, but every 3-axis sample is one U2D2
 * Sync Write packet. This keeps video, eyes, light and mechanics on one clock
 * without exposing the motors to three independently jittering USB writes. */
export async function startBakedMotorPlayback(): Promise<boolean> {
  if (useStore.getState().seq.id !== '08_exhibition_final') return false;
  const axes = ['yaw', 'tilt', 'body'] as Axis[];
  if (!hardwareOutputsEnabled() || !getU2D2Status().connected) return false;
  axes.forEach((axis) => { if (isFollowing(axis)) cancelFollowWithoutHold(axis); });
  if (bakedTimer) window.clearInterval(bakedTimer);
  const sendFrame = async () => {
    const s = useStore.getState(), t = Math.min(s.seq.durationSec, s.tSec + 0.04);
    const m = evaluateSequenceAt(s.seq, t).motion;
    const ok = await sendU2D2Goals({
      yaw: clampDeg('yaw', m.yawY), tilt: clampDeg('tilt', m.tiltZ), body: clampDeg('body', m.bodyYaw ?? 0),
    }, true);
    if (!ok && bakedTimer) { window.clearInterval(bakedTimer); bakedTimer = 0; bakedPlayback = false; emit(); }
  };
  bakedPlayback = await sendU2D2Goals({ yaw: clampDeg('yaw', wantNow('yaw')), tilt: clampDeg('tilt', wantNow('tilt')), body: clampDeg('body', wantNow('body')) }, true);
  if (bakedPlayback) bakedTimer = window.setInterval(() => void sendFrame(), 1000 / 30);
  emit();
  return bakedPlayback;
}

export async function stopBakedMotorPlayback() {
  if (bakedTimer) { window.clearInterval(bakedTimer); bakedTimer = 0; }
  bakedPlayback = false;
  if (getU2D2Status().connected) await Promise.all((['yaw', 'tilt', 'body'] as Axis[]).map((axis) => sendU2D2MotorCommand('hold', axis)));
  emit();
}

/** Cancel both browser followers and ask the UNO firmware to hold both axes. */
export async function holdAllMotors() {
  stopFollow('yaw'); stopFollow('tilt'); stopFollow('body');
  const result = await Promise.all([call('/hold', { axis: 'yaw' }), call('/hold', { axis: 'tilt' }), call('/hold', { axis: 'body' })]);
  await refreshMotor();
  return result;
}
/** What the editor shows for this axis right now: timeline value plus any slider/live override (so the slider drives the motor too). */
const wantNow = (axis: Axis) => { const m = useStore.getState().evalNow().motion; return axis === 'yaw' ? m.yawY : axis === 'body' ? (m.bodyYaw ?? 0) : m.tiltZ; };
const wantAt = (axis: Axis, tSec: number) => {
  const s = useStore.getState();
  const m = evaluateSequenceAt(s.seq, Math.max(0, Math.min(s.seq.durationSec, tSec))).motion;
  return axis === 'yaw' ? m.yawY : axis === 'body' ? (m.bodyYaw ?? 0) : m.tiltZ;
};
const clampDeg = (axis: Axis, d: number) => Math.max(-LIMITS[axis].limitDeg, Math.min(LIMITS[axis].limitDeg, d));

/** First move (slowly, via the motor's own slow profile) to where the editor's value is now; only then follow it, so the firmware tracking watchdog stays
 *  meaningful. While following, goals come out of followStep (speed + acceleration capped), so dragging the slider or scrubbing never commands a jump. */
export async function startFollow(axis: Axis = 'yaw') {
  if (!hardwareOutputsEnabled() || !getU2D2Status().connected) return;
  const f = follow[axis];
  if (f.timer || f.approaching) return;
  const run = ++f.run;
  f.approaching = true; emit();
  const t0 = performance.now();
  const target = clampDeg(axis, wantNow(axis));
  const first = await call('/goal', { axis, deg: target, follow: false });
  if (!first.ok) { f.approaching = false; await refreshMotor(); emit(); return; }
  while (f.approaching) {
    if (f.run !== run || !f.approaching || !hardwareOutputsEnabled() || !getU2D2Status().connected) return;
    await refreshMotor(true);
    if (f.run !== run || !f.approaching) return;
    if (Math.abs((getMotorStatus(axis).deg ?? 1e9) - target) < 1.5) break;
    if (performance.now() - t0 > 60000) { f.approaching = false; emit(); return; }
    await new Promise((res) => setTimeout(res, 250));
  }
  if (f.run !== run || !f.approaching) return;
  f.approaching = false; f.lastSent = NaN; f.lastSentAt = 0;
  let x = getMotorStatus(axis).deg ?? clampDeg(axis, wantNow(axis)), v = 0, busy = false;
  let lastStepAt = performance.now();
  f.timer = window.setInterval(async () => {
    if (f.run !== run) return;
    if (!hardwareOutputsEnabled() || !getU2D2Status().connected) { stopFollow(axis); return; }
    const stepAt = performance.now();
    const dt = Math.max(1 / 120, Math.min(0.1, (stepAt - lastStepAt) / 1000));
    lastStepAt = stepAt;
    if (useStore.getState().playing) {
      // Compensate only transport/write latency. Servo acceleration profiling
      // is disabled because the authored curve already contains acceleration;
      // this small horizon preserves keyframe timing without stop-start ramps.
      const s = useStore.getState();
      x = clampDeg(axis, wantAt(axis, s.tSec + 0.05));
      v = 0;
    } else {
      const r0 = followStep(x, v, wantNow(axis), dt, LIMITS[axis]);
      x = r0.x; v = r0.v;
    }
    const now = performance.now();
    if (Number.isFinite(f.lastSent) && Math.abs(x - f.lastSent) < 0.05 && now - f.lastSentAt < 300) return; // quiet, but keep the firmware watchdog fed
    if (busy) return;
    busy = true; f.lastSent = x; f.lastSentAt = now;
    const r = await call('/goal', { axis, deg: x, follow: true });
    busy = false;
    if (f.run !== run) return;
    if (!r.ok) { window.clearInterval(f.timer); f.timer = 0; await refreshMotor(); emit(); }
  }, 1000 / 30);
  emit();
}

// Locking output cancels approaching moves as well as active follower timers.
const unsubscribeOutputs = subscribeHardwareOutputs(() => {
  if (!hardwareOutputsEnabled()) for (const axis of ['yaw', 'tilt', 'body'] as Axis[]) stopFollow(axis);
});
const unsubscribePlayback = useStore.subscribe((state, previous) => {
  if (previous.playing && !state.playing) {
    if (bakedPlayback) { void stopBakedMotorPlayback().then(() => refreshMotor(true)); return; }
    // The final authored pose is zero. Give each linked axis one explicit final
    // target before Hold so the last timer tick cannot leave yaw short of home.
    for (const axis of ['yaw', 'tilt', 'body'] as Axis[]) {
      if (!isFollowing(axis)) continue;
      const target = clampDeg(axis, wantNow(axis));
      cancelFollowWithoutHold(axis);
      void call('/goal', { axis, deg: target, follow: false });
    }
    window.setTimeout(() => void refreshMotor(true), 800);
  }
});

if (import.meta.hot) import.meta.hot.dispose(() => {
  unsubscribeOutputs(); unsubscribePlayback(); window.clearInterval(poll); window.clearInterval(bakedTimer);
  for (const axis of ['yaw', 'tilt', 'body'] as Axis[]) stopFollow(axis);
});
