# 새 프로젝트 체크리스트

- [ ] `public/` 폴더를 그대로 복사했다.
- [ ] 시나리오 목록에는 07과 08만 등록했다.
- [ ] Arduino 눈·링 펌웨어를 업로드했다.
- [ ] Chrome/Edge에서 Arduino와 U2D2를 서로 다른 포트로 선택했다.
- [ ] U2D2에서 ID 1, 2, 3이 모두 응답한다.
- [ ] ID 4 Rail Torque가 OFF다.
- [ ] 세 축의 Hardware Error Status가 0이다.
- [ ] Profile Velocity가 0이 아닌 안전값으로 읽힌다.
- [ ] 각 축을 현재 위치 목표로 설정한 다음 Torque ON 했다.
- [ ] 작은 범위의 3축 Sync Write 시험을 통과했다.
- [ ] Pause, E-STOP, USB 분리 시 Hold가 실행된다.
- [ ] Final 영상·오디오·눈·링·모터가 하나의 재생 시계를 사용한다.
- [ ] 전체 범위 시험 전에 주변 사람과 장애물을 치웠다.

