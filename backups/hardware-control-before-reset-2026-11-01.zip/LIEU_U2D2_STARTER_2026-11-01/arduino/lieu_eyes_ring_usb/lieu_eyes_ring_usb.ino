// LIEU minimal USB firmware: two HT16K33 8x8 eyes + 24px SK6812 RGBW ring.
// Motors are intentionally NOT controlled here. The browser talks directly
// to a separate ROBOTIS U2D2 for DYNAMIXEL IDs 1/2/3.
#include <Wire.h>
#include <Adafruit_NeoPixel.h>

#define PIN_RING 6
#define RING_COUNT 24
#define LED_TYPE (NEO_GRBW + NEO_KHZ800)
#define USB_BAUD 115200

static const uint8_t SYNC0 = 0xAA, SYNC1 = 0x55;
enum : uint8_t { T_FRAME = 1, T_CONFIG = 2, T_INFO = 3, T_BLANK = 4, T_MOTOR = 5 };
static const uint8_t FRAME_LEN = 8 + 8 + 2 + RING_COUNT * 4;
static const uint32_t WATCHDOG_MS = 2000;

Adafruit_NeoPixel ring(RING_COUNT, PIN_RING, LED_TYPE);
uint8_t eyeAddr[2] = {0x70, 0x71};
uint8_t eyeDim[2] = {255, 255};
uint8_t maxScale = 64;
uint16_t budgetMa = 400;
uint8_t ringFrom[RING_COUNT * 4] = {0};
uint8_t ringTarget[RING_COUNT * 4] = {0};
uint8_t ringShown[RING_COUNT * 4] = {0};
uint32_t ringBlendAt = 0, ringDrawAt = 0, lastFrameAt = 0;
uint32_t frames = 0, badPackets = 0, i2cErrors = 0;
bool outputActive = false;

static const uint8_t IDLE_L[8] = {0, 16, 56, 56, 56, 56, 16, 0};
static const uint8_t IDLE_R[8] = {0, 8, 28, 28, 28, 28, 8, 0};

void htCmd(uint8_t addr, uint8_t command) {
  Wire.beginTransmission(addr); Wire.write(command);
  if (Wire.endTransmission() != 0) i2cErrors++;
}
void htInit(uint8_t addr) { htCmd(addr, 0x21); htCmd(addr, 0x81); htCmd(addr, 0xEF); }
void htShow(uint8_t side, const uint8_t* rows, uint8_t dim) {
  if (dim != eyeDim[side]) { htCmd(eyeAddr[side], 0xE0 | (dim & 15)); eyeDim[side] = dim; }
  Wire.beginTransmission(eyeAddr[side]); Wire.write((uint8_t)0);
  for (uint8_t row = 0; row < 8; row++) { Wire.write(rows[row]); Wire.write((uint8_t)0); }
  if (Wire.endTransmission() != 0) i2cErrors++;
}
bool i2cPresent(uint8_t addr) { Wire.beginTransmission(addr); return Wire.endTransmission() == 0; }

void ringShow(const uint8_t* pixels) {
  uint32_t sum = 0;
  for (uint16_t i = 0; i < RING_COUNT * 4; i++) sum += pixels[i];
  uint32_t scale = maxScale;
  const uint32_t estimate = (sum * 20UL / 255UL) * scale / 255UL;
  if (estimate > budgetMa) scale = scale * budgetMa / estimate;
  for (uint8_t i = 0; i < RING_COUNT; i++) {
    const uint8_t* p = pixels + i * 4;
    ring.setPixelColor(i, ring.Color(p[0] * scale / 255, p[1] * scale / 255, p[2] * scale / 255, p[3] * scale / 255));
  }
  ring.show();
}
void pumpRing(bool force = false) {
  const uint32_t now = millis();
  if (!force && now - ringDrawAt < 10) return;
  ringDrawAt = now;
  const uint32_t age = now - ringBlendAt;
  const uint16_t u = age >= 34 ? 256 : (uint16_t)(age * 256UL / 34UL);
  for (uint16_t i = 0; i < RING_COUNT * 4; i++)
    ringShown[i] = (uint8_t)(((uint16_t)ringFrom[i] * (256 - u) + (uint16_t)ringTarget[i] * u) >> 8);
  ringShow(ringShown);
}
void setRingTarget(const uint8_t* pixels) {
  pumpRing(true);
  memcpy(ringFrom, ringShown, sizeof(ringFrom));
  memcpy(ringTarget, pixels, sizeof(ringTarget));
  ringBlendAt = millis();
}
void safeBlank() {
  uint8_t zero[RING_COUNT * 4] = {0};
  htShow(0, IDLE_L, 13); htShow(1, IDLE_R, 13);
  memcpy(ringFrom, zero, sizeof(ringFrom));
  memcpy(ringTarget, zero, sizeof(ringTarget));
  memcpy(ringShown, zero, sizeof(ringShown));
  ringShow(zero); outputActive = false;
}
void onFrame(const uint8_t* payload) {
  htShow(0, payload, payload[16]); htShow(1, payload + 8, payload[17]);
  setRingTarget(payload + 18); lastFrameAt = millis(); frames++; outputActive = true;
}
void onConfig(const uint8_t* p, uint8_t n) {
  if (n < 5) return;
  eyeAddr[0] = p[0]; eyeAddr[1] = p[1]; maxScale = p[2]; budgetMa = ((uint16_t)p[3] << 8) | p[4];
  eyeDim[0] = eyeDim[1] = 255; htInit(eyeAddr[0]); htInit(eyeAddr[1]);
  Serial.print(F("CONFIG eyeL=0x")); Serial.print(eyeAddr[0], HEX);
  Serial.print(F(" eyeR=0x")); Serial.print(eyeAddr[1], HEX);
  Serial.print(F(" scale=")); Serial.print(maxScale); Serial.print(F(" budget_mA=")); Serial.println(budgetMa);
}
void onInfo() {
  Serial.print(F("INFO LIEU-HW fw=eyes-ring-usb board=UNO-R4 eyeL=0x"));
  Serial.print(eyeAddr[0], HEX); Serial.print(i2cPresent(eyeAddr[0]) ? F(":ok") : F(":MISSING"));
  Serial.print(F(" eyeR=0x")); Serial.print(eyeAddr[1], HEX); Serial.println(i2cPresent(eyeAddr[1]) ? F(":ok") : F(":MISSING"));
  Serial.print(F("frames=")); Serial.print(frames); Serial.print(F(" bad=")); Serial.print(badPackets);
  Serial.print(F(" i2cErr=")); Serial.println(i2cErrors);
}
void dispatch(uint8_t type, const uint8_t* payload, uint8_t length) {
  if (type == T_FRAME && length == FRAME_LEN) onFrame(payload);
  else if (type == T_CONFIG) onConfig(payload, length);
  else if (type == T_INFO) onInfo();
  else if (type == T_BLANK) safeBlank();
  else if (type == T_MOTOR) Serial.println(F("MOTOR external=U2D2"));
}
void pumpSerial() {
  static uint8_t state = 0, type = 0, length = 0, index = 0, sum = 0, payload[255];
  uint16_t processed = 0;
  while (Serial.available() && processed++ < 256) {
    const uint8_t b = Serial.read();
    switch (state) {
      case 0: state = b == SYNC0 ? 1 : 0; break;
      case 1: state = b == SYNC1 ? 2 : (b == SYNC0 ? 1 : 0); break;
      case 2: type = b; sum = b; state = 3; break;
      case 3: length = b; sum += b; index = 0; state = length ? 4 : 5; break;
      case 4: payload[index++] = b; sum += b; if (index == length) state = 5; break;
      case 5:
        if (b == sum) dispatch(type, payload, length);
        else { badPackets++; Serial.println(F("ERR checksum")); }
        state = 0; break;
    }
  }
}

void setup() {
  Serial.begin(USB_BAUD);
  Wire.begin(); Wire.setClock(400000);
  ring.begin(); htInit(eyeAddr[0]); htInit(eyeAddr[1]); safeBlank();
  const uint32_t start = millis(); while (!Serial && millis() - start < 1500) {}
  Serial.println(F("READY LIEU-HW fw=eyes-ring-usb UNO-R4 U2D2-EXTERNAL"));
  onInfo();
}
void loop() {
  pumpSerial();
  if (outputActive) pumpRing();
  if (outputActive && millis() - lastFrameAt > WATCHDOG_MS) safeBlank();
}

