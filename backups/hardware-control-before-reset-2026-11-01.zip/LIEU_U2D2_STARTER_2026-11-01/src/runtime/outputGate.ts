/**
 * Process-local master gate for every physical output.
 * Deliberately not persisted: reloading always returns to monitoring-only mode.
 */
let enabled = false;
const listeners = new Set<() => void>();

export const hardwareOutputsEnabled = () => enabled;
export const subscribeHardwareOutputs = (fn: () => void) => { listeners.add(fn); return () => listeners.delete(fn); };

export function setHardwareOutputsEnabled(next: boolean) {
  if (enabled === next) return;
  enabled = next;
  listeners.forEach((fn) => fn());
}
