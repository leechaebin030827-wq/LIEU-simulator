import { hardwareOutputsEnabled } from './outputGate';

/** Direct browser control for a ROBOTIS U2D2 (FT232H, Protocol 2.0).
 * Arduino remains a separate USB device for eyes/ring. Motor writes are
 * allow-listed here and all multi-axis motion uses one Sync Write packet. */
export type U2D2Axis = 'yaw' | 'tilt' | 'body';
export type U2D2MotorStatus = {
  ok: boolean; error?: string; torque: boolean; mode: number; profile_ok: boolean;
  deg: number | null; hw_error: number; fault: string | null; needs_front: boolean;
  limit_deg: number; follow?: boolean;
};
export type U2D2Status = { connected: boolean; busy: boolean; message: string };

type AxisConfig = {
  id: number; limit: number; profileAcc: number; profileVel: number;
  toRaw: (deg: number) => number; toDeg: (raw: number) => number;
};

const AXES: Record<U2D2Axis, AxisConfig> = {
  yaw: { id: 1, limit: 90, profileAcc: 20, profileVel: 275,
    toRaw: (d) => Math.round(3107 + d * 71.6556), toDeg: (r) => (r - 3107) / 71.6556 },
  tilt: { id: 2, limit: 15, profileAcc: 4, profileVel: 31,
    toRaw: (d) => d >= 0 ? Math.round(2050 - d * (214 / 15)) : Math.round(2050 + -d * (200 / 15)),
    toDeg: (r) => r <= 2050 ? (2050 - r) * (15 / 214) : -(r - 2050) * (15 / 200) },
  body: { id: 3, limit: 170, profileAcc: 8, profileVel: 154,
    toRaw: (d) => Math.round(2296 + d * 40.0611), toDeg: (r) => (r - 2296) / 40.0611 },
};
const BY_ID = new Map(Object.entries(AXES).map(([name, cfg]) => [cfg.id, name as U2D2Axis]));
const U2D2_VID = 0x0403, U2D2_PID = 0x6014, BAUD = 115200;
const INST_PING = 0x01, INST_READ = 0x02, INST_WRITE = 0x03, INST_SYNC_WRITE = 0x83;
const ADDR_MODE = 11, ADDR_TORQUE = 64, ADDR_HW_ERROR = 70;
const ADDR_PROFILE_ACC = 108, ADDR_PROFILE_VEL = 112, ADDR_GOAL = 116, ADDR_PRESENT = 132;

const empty = (axis: U2D2Axis): U2D2MotorStatus => ({ ok: false, error: `${axis} motor not found on U2D2`, torque: false,
  mode: 0, profile_ok: false, deg: null, hw_error: 0, fault: null, needs_front: false, limit_deg: AXES[axis].limit });
let motor: Record<U2D2Axis, U2D2MotorStatus> = { yaw: empty('yaw'), tilt: empty('tilt'), body: empty('body') };
let state: U2D2Status = { connected: false, busy: false, message: 'U2D2 연결 안 됨' };
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((f) => f());
const setState = (p: Partial<U2D2Status>) => { state = { ...state, ...p }; emit(); };

let port: any = null, reader: any = null, writer: any = null;
let generation = 0, readTask: Promise<void> | null = null;
let busQueue: Promise<unknown> = Promise.resolve();
let rx = new Uint8Array(0);
type Reply = { id: number; error: number; params: Uint8Array };
type Waiter = { id: number; resolve: (r: Reply) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> };
const waiters: Waiter[] = [];
const following: Record<U2D2Axis, boolean> = { yaw: false, tilt: false, body: false };
const lastGoalAt: Record<U2D2Axis, number> = { yaw: 0, tilt: 0, body: 0 };
let watchdog = 0;

export const u2d2Supported = () => typeof navigator !== 'undefined' && 'serial' in navigator;
export const getU2D2Status = () => state;
export const getU2D2MotorStatus = (axis: U2D2Axis) => motor[axis];
export const subscribeU2D2 = (f: () => void) => { listeners.add(f); return () => listeners.delete(f); };

function crc16(data: Uint8Array): number {
  let crc = 0;
  for (const b of data) {
    crc ^= b << 8;
    for (let i = 0; i < 8; i++) crc = crc & 0x8000 ? ((crc << 1) ^ 0x8005) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc;
}

function packet(id: number, instruction: number, params: number[] | Uint8Array = []): Uint8Array {
  const p = Array.from(params), length = p.length + 3;
  const body = Uint8Array.from([0xff, 0xff, 0xfd, 0x00, id, length & 255, length >> 8, instruction, ...p]);
  const crc = crc16(body);
  return Uint8Array.from([...body, crc & 255, crc >> 8]);
}

function appendRx(value: Uint8Array) {
  const joined = new Uint8Array(rx.length + value.length);
  joined.set(rx); joined.set(value, rx.length); rx = joined;
  while (rx.length >= 11) {
    let start = -1;
    for (let i = 0; i <= rx.length - 4; i++) {
      if (rx[i] === 0xff && rx[i + 1] === 0xff && rx[i + 2] === 0xfd && rx[i + 3] === 0) { start = i; break; }
    }
    if (start < 0) { rx = rx.slice(Math.max(0, rx.length - 3)); return; }
    if (start) rx = rx.slice(start);
    if (rx.length < 7) return;
    const length = rx[5] | (rx[6] << 8), total = 7 + length;
    if (rx.length < total) return;
    const frame = rx.slice(0, total); rx = rx.slice(total);
    const expected = frame[total - 2] | (frame[total - 1] << 8);
    if (crc16(frame.slice(0, -2)) !== expected || frame[7] !== 0x55) continue;
    const reply: Reply = { id: frame[4], error: frame[8], params: frame.slice(9, -2) };
    const index = waiters.findIndex((w) => w.id === reply.id);
    if (index >= 0) {
      const [w] = waiters.splice(index, 1); clearTimeout(w.timer); w.resolve(reply);
    }
  }
}

async function pumpRead(session: number) {
  try {
    while (session === generation && reader) {
      const { value, done } = await reader.read();
      if (done) break;
      if (value?.length) appendRx(value);
    }
  } catch (e) {
    if (session === generation) void disconnectU2D2(`U2D2 읽기 실패 · ${(e as Error).message}`);
  }
}

function waitReply(id: number, timeout = 350): Promise<Reply> {
  return new Promise((resolve, reject) => {
    const waiter: Waiter = { id, resolve, reject, timer: setTimeout(() => {
      const i = waiters.indexOf(waiter); if (i >= 0) waiters.splice(i, 1);
      reject(new Error(`DYNAMIXEL ID ${id} 응답 시간 초과`));
    }, timeout) };
    waiters.push(waiter);
  });
}

function queued<T>(fn: () => Promise<T>): Promise<T> {
  const operation = busQueue.then(fn, fn);
  busQueue = operation.catch(() => undefined);
  return operation;
}

async function exchange(id: number, instruction: number, params: number[] | Uint8Array = []): Promise<Reply> {
  return queued(async () => {
    if (!writer) throw new Error('U2D2가 연결되지 않았습니다');
    const reply = waitReply(id);
    await writer.write(packet(id, instruction, params));
    const result = await reply;
    if (result.error) throw new Error(`DYNAMIXEL ID ${id} 오류 0x${result.error.toString(16).padStart(2, '0')}`);
    return result;
  });
}

const bytes = (value: number, size: number, signed = false) => {
  const b = new ArrayBuffer(size), v = new DataView(b);
  if (size === 1) v.setUint8(0, value); else if (signed) v.setInt32(0, value, true); else v.setUint32(0, value, true);
  return Array.from(new Uint8Array(b));
};
const numberFrom = (data: Uint8Array, signed = false) => {
  const copy = data.slice().buffer, v = new DataView(copy);
  return data.length === 1 ? v.getUint8(0) : signed ? v.getInt32(0, true) : v.getUint32(0, true);
};
async function readReg(id: number, addr: number, size: number, signed = false) {
  const r = await exchange(id, INST_READ, [addr & 255, addr >> 8, size & 255, size >> 8]);
  if (r.params.length !== size) throw new Error(`ID ${id} 레지스터 ${addr} 길이 오류`);
  return numberFrom(r.params, signed);
}
async function writeReg(id: number, addr: number, value: number, size: number, signed = false) {
  await exchange(id, INST_WRITE, [addr & 255, addr >> 8, ...bytes(value, size, signed)]);
}

async function refreshAxis(axis: U2D2Axis): Promise<U2D2MotorStatus> {
  const c = AXES[axis];
  try {
    await exchange(c.id, INST_PING);
    const [mode, torque, hw, profile, present] = await Promise.all([
      readReg(c.id, ADDR_MODE, 1), readReg(c.id, ADDR_TORQUE, 1), readReg(c.id, ADDR_HW_ERROR, 1),
      readReg(c.id, ADDR_PROFILE_VEL, 4), readReg(c.id, ADDR_PRESENT, 4, true),
    ]);
    const previousFault = motor[axis].fault;
    return motor[axis] = { ok: true, torque: torque === 1, mode, profile_ok: profile > 0 && profile <= c.profileVel,
      deg: c.toDeg(present), hw_error: hw, fault: hw ? `모터 하드웨어 오류 ${hw}` : previousFault,
      needs_front: false, limit_deg: c.limit, follow: following[axis] };
  } catch (e) {
    return motor[axis] = { ...empty(axis), error: (e as Error).message, fault: motor[axis].fault };
  }
}

export async function refreshU2D2(axis?: U2D2Axis) {
  if (!state.connected) return;
  if (axis) await refreshAxis(axis);
  else for (const a of ['yaw', 'tilt', 'body'] as U2D2Axis[]) await refreshAxis(a);
  emit();
}

async function openPort(selected: any) {
  const session = ++generation;
  port = selected;
  await port.open({ baudRate: BAUD, dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none' });
  writer = port.writable.getWriter(); reader = port.readable.getReader(); rx = new Uint8Array(0);
  readTask = pumpRead(session);
  setState({ connected: true, busy: false, message: 'U2D2 connected · COM motor bus' });
  // ID 4 is the rail and is never part of motion. Keep it released whenever a
  // U2D2 session starts; IDs 1..3 are still left exactly as found.
  try { await writeReg(4, ADDR_TORQUE, 0, 1); } catch { /* optional rail may be absent */ }
  await refreshU2D2();
  if (!watchdog) watchdog = window.setInterval(() => {
    const now = performance.now();
    for (const axis of ['yaw', 'tilt', 'body'] as U2D2Axis[]) {
      if (following[axis] && now - lastGoalAt[axis] > 650) void sendU2D2MotorCommand('hold', axis);
    }
  }, 100);
}

export async function connectU2D2() {
  if (!u2d2Supported()) { setState({ message: 'U2D2 USB 연결은 Chrome/Edge가 필요합니다' }); return false; }
  if (state.connected || state.busy) return state.connected;
  setState({ busy: true, message: 'U2D2 포트 선택 중…' });
  try {
    const serial = (navigator as any).serial;
    const known = (await serial.getPorts()).find((p: any) => {
      const i = p.getInfo?.() ?? {}; return i.usbVendorId === U2D2_VID && i.usbProductId === U2D2_PID;
    });
    const selected = known ?? await serial.requestPort({ filters: [{ usbVendorId: U2D2_VID, usbProductId: U2D2_PID }] });
    await openPort(selected); return true;
  } catch (e) {
    await disconnectU2D2(`U2D2 연결 실패 · ${(e as Error).message}`); return false;
  }
}

export async function autoConnectU2D2() {
  if (!u2d2Supported() || state.connected || state.busy) return state.connected;
  try {
    const ports = await (navigator as any).serial.getPorts();
    const known = ports.find((p: any) => { const i = p.getInfo?.() ?? {}; return i.usbVendorId === U2D2_VID && i.usbProductId === U2D2_PID; });
    if (!known) return false;
    setState({ busy: true, message: '기존 U2D2 권한으로 연결 중…' }); await openPort(known); return true;
  } catch (e) { await disconnectU2D2(`U2D2 자동 연결 실패 · ${(e as Error).message}`); return false; }
}

export async function disconnectU2D2(message = 'U2D2 연결 안 됨') {
  const oldReader = reader, oldWriter = writer, oldPort = port;
  ++generation; reader = writer = port = null;
  for (const a of ['yaw', 'tilt', 'body'] as U2D2Axis[]) following[a] = false;
  for (const w of waiters.splice(0)) { clearTimeout(w.timer); w.reject(new Error('U2D2 disconnected')); }
  if (watchdog) { window.clearInterval(watchdog); watchdog = 0; }
  try { await oldReader?.cancel(); } catch { /* already closed */ }
  try { oldReader?.releaseLock(); } catch { /* already closed */ }
  try { oldWriter?.releaseLock(); } catch { /* already closed */ }
  try { await oldPort?.close(); } catch { /* already closed */ }
  readTask = null; motor = { yaw: empty('yaw'), tilt: empty('tilt'), body: empty('body') };
  setState({ connected: false, busy: false, message });
}

async function arm(axis: U2D2Axis) {
  const c = AXES[axis];
  const hw = await readReg(c.id, ADDR_HW_ERROR, 1);
  if (hw) throw new Error(`${axis} 하드웨어 오류 ${hw}`);
  let torque = await readReg(c.id, ADDR_TORQUE, 1);
  if (torque) await writeReg(c.id, ADDR_TORQUE, 0, 1);
  if (await readReg(c.id, ADDR_MODE, 1) !== 4) await writeReg(c.id, ADDR_MODE, 4, 1);
  await writeReg(c.id, ADDR_PROFILE_ACC, c.profileAcc, 4);
  await writeReg(c.id, ADDR_PROFILE_VEL, c.profileVel, 4);
  const present = await readReg(c.id, ADDR_PRESENT, 4, true);
  await writeReg(c.id, ADDR_GOAL, present, 4, true);
  await writeReg(c.id, ADDR_TORQUE, 1, 1);
  torque = await readReg(c.id, ADDR_TORQUE, 1);
  if (!torque || await readReg(c.id, ADDR_PROFILE_VEL, 4) !== c.profileVel) throw new Error(`${axis} Arm 검증 실패`);
}

export type U2D2Command = 'arm' | 'hold' | 'release' | 'clear' | 'setup' | 'goal' | 'status';
export async function sendU2D2MotorCommand(name: U2D2Command, axis: U2D2Axis = 'yaw', deg = 0, follow = false): Promise<U2D2MotorStatus> {
  if (!state.connected) return { ...empty(axis), error: 'U2D2가 연결되지 않았습니다' };
  if (!['hold', 'release', 'status'].includes(name) && !hardwareOutputsEnabled()) return { ...motor[axis], ok: false, error: 'hardware outputs are locked' };
  const c = AXES[axis];
  try {
    if (name === 'status') return await refreshAxis(axis);
    if (name === 'clear') motor[axis] = { ...motor[axis], fault: null };
    else if (name === 'arm' || name === 'setup') await arm(axis);
    else if (name === 'release') { following[axis] = false; await writeReg(c.id, ADDR_TORQUE, 0, 1); }
    else if (name === 'hold') {
      following[axis] = false;
      if (await readReg(c.id, ADDR_TORQUE, 1)) await writeReg(c.id, ADDR_GOAL, await readReg(c.id, ADDR_PRESENT, 4, true), 4, true);
    } else if (name === 'goal') {
      if (!Number.isFinite(deg) || Math.abs(deg) > c.limit) throw new Error(`${axis} 목표가 ±${c.limit}° 범위를 벗어남`);
      if (!motor[axis].torque || !motor[axis].profile_ok || motor[axis].fault) throw new Error(`${axis}가 안전하게 Arm되지 않았습니다`);
      await writeReg(c.id, ADDR_GOAL, c.toRaw(deg), 4, true);
      following[axis] = follow; lastGoalAt[axis] = performance.now();
      motor[axis] = { ...motor[axis], follow };
      return motor[axis];
    }
    await refreshAxis(axis); emit(); return motor[axis];
  } catch (e) {
    following[axis] = false;
    motor[axis] = { ...motor[axis], ok: false, fault: (e as Error).message, error: (e as Error).message };
    emit(); return motor[axis];
  }
}

/** One Protocol 2.0 broadcast packet updates every requested axis atomically. */
export async function sendU2D2Goals(goals: Partial<Record<U2D2Axis, number>>, follow = true): Promise<boolean> {
  if (!state.connected || !hardwareOutputsEnabled()) return false;
  const params: number[] = [ADDR_GOAL & 255, ADDR_GOAL >> 8, 4, 0];
  const axes = (Object.keys(goals) as U2D2Axis[]).filter((axis) => goals[axis] != null);
  try {
    for (const axis of axes) {
      const c = AXES[axis], deg = goals[axis]!;
      if (!Number.isFinite(deg) || Math.abs(deg) > c.limit) throw new Error(`${axis} 목표 범위 초과`);
      if (!motor[axis].torque || !motor[axis].profile_ok || motor[axis].fault) throw new Error(`${axis} Arm 필요`);
      params.push(c.id, ...bytes(c.toRaw(deg), 4, true));
    }
    await queued(async () => {
      if (!writer) throw new Error('U2D2 disconnected');
      await writer.write(packet(0xfe, INST_SYNC_WRITE, params));
    });
    const now = performance.now();
    for (const axis of axes) { following[axis] = follow; lastGoalAt[axis] = now; motor[axis] = { ...motor[axis], follow }; }
    return true;
  } catch (e) {
    for (const axis of axes) { following[axis] = false; motor[axis] = { ...motor[axis], ok: false, fault: (e as Error).message, error: (e as Error).message }; }
    emit(); return false;
  }
}

