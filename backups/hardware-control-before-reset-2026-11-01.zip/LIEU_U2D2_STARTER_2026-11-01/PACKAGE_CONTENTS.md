# 패키지 구성

- `START_HERE.md`: 새 프로젝트 이식·배선·안전·재생 설명서
- `public/examples/07_bonus_aegyo.lieu.json`: 애교 대폭발
- `public/examples/08_exhibition_final.lieu.json`: Final Exhibition
- `public/examples/media/`: 위 두 시나리오가 참조하는 오디오·SVG만 포함
- `public/assets/LIEU-Exhibition-Scenario-web.mp4`: Final TV 영상
- `src/engine/`: 시나리오 평가기와 간단한 8×8 눈 라이브러리
- `src/eyestudio/`: 다양한 눈 감정·동작·시선·이모지 소스 전체
- `src/runtime/u2d2.ts`: 브라우저 Web Serial U2D2 Protocol 2.0 제어
- `src/runtime/outputGate.ts`: 물리 출력 잠금 예제
- `config/motor-hardware.json`: 새 프로젝트용 정리된 모터 기준값
- `config/motor_limits.full.json`: 기존 실측 이력 전체
- `arduino/lieu_eyes_ring_usb/`: 눈·링 전용 UNO R4 펌웨어
- `reference/lieu_eyes_all_640x320.mp4`: 눈 패키지 미리보기

의도적으로 제외한 항목:

- 나머지 시나리오 01~06
- 시나리오 백업 파일
- `node_modules`, `dist`, 개발 캐시
- 쉴드 모터 제어 펌웨어
- Wi‑Fi SSID/비밀번호
- 기존 프로젝트 UI 전체와 GLB 시뮬레이터 모델

