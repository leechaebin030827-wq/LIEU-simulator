# LIEU U2D2 최소 스타터

이 ZIP은 기존 시뮬레이터 전체를 복사하지 않고, 새 프로젝트에서 다음 두 연출과 실제 하드웨어를 다시 시작하는 데 필요한 자료만 모은 패키지입니다.

- `07_bonus_aegyo` — 애교 대폭발
- `08_exhibition_final` — Final Exhibition
- 8×8 도트 매트릭스 기본 표정·감정 애니메이션
- Eye Studio의 다양한 감정·동작·시선·이모지 패키지
- U2D2 Protocol 2.0 3축 모터 제어 코드와 실측 보정값
- Arduino UNO R4 눈·RGBW 링 전용 USB 펌웨어
- 두 시나리오가 참조하는 영상·오디오·SVG 전체

## 1. 하드웨어 구조

```text
Chrome/Edge 웹 프로젝트
  ├─ USB Web Serial → Arduino UNO R4 (눈 2개 + RGBW 링만)
  └─ USB Web Serial → U2D2 → DYNAMIXEL ID 1/2/3

DYNAMIXEL ID 4 Rail은 이번 패키지에서 절대 움직이지 않으며 Torque OFF만 유지합니다.
```

실제 연결:

| 장치 | 현재 PC에서 확인된 포트 | 역할 |
|---|---:|---|
| Arduino UNO R4 WiFi | COM3 | HT16K33 눈 2개, 24px SK6812 RGBW 링 |
| ROBOTIS U2D2 | COM4 | DYNAMIXEL Yaw/Tilt/Body |

COM 번호는 다른 PC에서 바뀔 수 있습니다. 브라우저 포트 선택창의 장치 이름과 VID/PID로 구분하십시오.

## 2. 새 웹 프로젝트에 복사할 것

1. 이 패키지의 `public/` 폴더를 새 프로젝트의 `public/`에 병합합니다.
2. `src/engine/`은 시나리오 데이터 평가와 간단한 8×8 표정 라이브러리입니다.
3. `src/eyestudio/`는 다양한 눈 감정·동작·시선·이모지 생성 패키지입니다.
4. `src/runtime/u2d2.ts`를 새 프로젝트에 복사합니다.
5. `u2d2.ts`가 사용하는 출력 잠금 인터페이스 예시는 `src/runtime/outputGate.ts`입니다.
6. `config/motor-hardware.json`을 단일 기준값으로 사용하십시오.

Eye Studio에서 MP4 내보내기까지 사용할 경우:

```bash
npm install mp4-muxer
```

시나리오 JSON의 미디어 경로는 ZIP 내부 `public/` 구조와 맞춰져 있으므로 파일명과 폴더를 바꾸지 않는 것이 안전합니다.

## 3. U2D2 연결 순서

Web Serial은 Chrome 또는 Edge의 `localhost` 페이지에서 사용합니다.

1. U2D2와 Arduino를 모두 USB에 연결합니다.
2. Arduino 포트 선택에서 Arduino UNO R4를 선택합니다.
3. U2D2 포트 선택에서 `USB Serial Port`, VID `0403`, PID `6014` 장치를 선택합니다.
4. U2D2 연결 직후 ID 1/2/3 상태를 읽습니다.
5. Arm은 다음 순서만 허용합니다.
   - Torque OFF
   - Extended Position Mode(4)
   - Profile Acceleration/Velocity 설정
   - Present Position을 Goal Position에 기록
   - Hardware Error 0 확인
   - Torque ON
6. 재생 중 Yaw/Tilt/Body 목표값은 축별 Write 세 번이 아니라 하나의 Sync Write로 전송합니다.
7. 명령이 650ms 이상 끊기면 현재 위치 Hold를 실행합니다.

`src/runtime/u2d2.ts`에 위 안전 순서와 Protocol 2.0 CRC, 상태 응답 파서, 3축 Sync Write가 구현되어 있습니다.

## 4. 모터 ID와 기준값

| ID | 축 | 0° raw | 안전 각도 | Profile Acc | Profile Vel |
|---:|---|---:|---:|---:|---:|
| 1 | Yaw | 3107 | ±90° | 20 | 275 |
| 2 | Tilt | 2050 | ±15° | 4 | 31 |
| 3 | Body | 2296 | ±170° | 8 | 154 |
| 4 | Rail | 사용 금지 | 제어하지 않음 | — | — |

- Baud: `115200`
- Protocol: `2.0`
- Goal Position 주소: `116`, 길이 `4 byte`
- Present Position 주소: `132`, 길이 `4 byte`
- Torque Enable 주소: `64`
- Hardware Error Status 주소: `70`

정확한 수식과 실측 이력은 `config/motor-hardware.json` 및 `config/motor_limits.full.json`에 있습니다.

## 5. Arduino 눈·링

`arduino/lieu_eyes_ring_usb/lieu_eyes_ring_usb.ino`는 쉴드 모터 코드를 완전히 제거한 최소 펌웨어입니다.

- 눈: HT16K33 8×8 두 개, 기본 주소 `0x70`, `0x71`
- I²C: SDA=A4, SCL=A5, 400kHz
- 링: SK6812 RGBW 24px, DIN=D6
- USB Serial: 115200bps
- 필요한 Arduino 라이브러리: `Adafruit NeoPixel`
- 연결이 끊겨도 눈은 기본 표정을 유지하고 링만 꺼집니다.

Arduino IDE에서 UNO R4 WiFi 보드를 선택하고 펌웨어를 업로드하십시오. Wi‑Fi 비밀번호는 필요하지 않습니다.

## 6. 시나리오 재생

두 시나리오 모두 `fps: 30`의 동일한 타임라인에서 다음 트랙을 평가합니다.

- `tracks.motion`: Yaw, Tilt, Body
- `tracks.eyes`: 두 눈 8×8 bitmap/intensity
- `tracks.ring24`: 24개 RGBW 픽셀
- `tracks.projector`: SVG/영상 연출
- `tracks.audio`: 음성·효과음
- `tracks.events`: 큐 이벤트

Final Exhibition에서 모터는 브라우저의 재생 시간 `tSec`와 동일한 시간으로 평가하고, 약 40ms의 전송 보정만 더한 뒤 30Hz Sync Write로 보냅니다. 영상과 모터를 서로 다른 타이머로 시작하지 마십시오.

권장 시작 순서:

1. 출력 잠금 상태에서 Arduino와 U2D2 연결
2. ID 1/2/3 상태 확인
3. 주변 안전 확인 후 출력 잠금 해제
4. 세 축 Arm
5. 시나리오 첫 프레임 위치로 천천히 이동
6. 도착 확인 후 영상·오디오·눈·링·모터의 공통 재생 시계 시작
7. Pause/E-STOP/연결 해제 시 세 축 Hold

## 7. 눈 패키지 안내

간단한 8×8 도트 표현만 필요하면:

- `src/engine/eyePresets.ts`
- `src/engine/emotions.ts`

고급 표현과 편집기를 사용하려면 `src/eyestudio/` 전체를 사용합니다. 포함된 범주:

- 감정: 기본, 행복, 신남, 수줍음, 차분, 안심, 호기심, 집중, 놀람, 걱정, 슬픔, 피곤, 졸림, 지루함, 우쭐, 의심, 짜증, 화남
- 동작: 인사, 끄덕임, 좌우 흔들기, 깨어나기, 잠들기, 하품, 웃음, 반짝임, 윙크, 여러 종류의 깜빡임
- 시선: 8방향, 힐끗 보기, 두리번, 훑기, 눈 굴리기, 정면 복귀
- 이모지: 하트, 별, 반짝, X, 나선, 달, 점, 다이아, 왕눈 등

`reference/lieu_eyes_all_640x320.mp4`는 전체 눈 표현을 빠르게 확인하기 위한 참고 영상입니다.

## 8. 절대 지킬 것

- 모터 외부 전원을 USB 5V에서 공급하지 마십시오.
- Profile Velocity `0`은 정지가 아니라 무제한 속도입니다. 0 상태에서 Torque를 켜고 Goal을 쓰지 마십시오.
- ID 4 Rail에는 Goal Position을 보내지 마십시오.
- 새 기구나 기어를 장착했다면 기존 raw 보정값을 그대로 믿지 말고 Torque OFF 상태에서 다시 측정하십시오.
- 브라우저 새로고침 후에는 연결·모드·프로파일·현재 위치를 다시 검증하십시오.
- Wi‑Fi 비밀번호, 개인 경로, 기존 프로젝트의 임시 백업은 이 ZIP에 포함하지 않았습니다.

