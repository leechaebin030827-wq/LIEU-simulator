import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
const hw = vi.hoisted(() => ({ send: vi.fn(), axis: vi.fn(), connected: true }));
vi.mock('../runtime/u2d2', () => ({
  getU2D2Status: () => ({ connected: hw.connected }),
  getU2D2MotorStatus: hw.axis, sendU2D2MotorCommand: hw.send,
  sendU2D2Goals: vi.fn().mockResolvedValue(true),
}));
let motor: typeof import('../runtime/motor');
let gate: typeof import('../runtime/outputGate');
const good = { ok: true, torque: true, mode: 4, profile_ok: true, deg: 0, fault: null, needs_front: false, hw_error: 0, limit_deg: 13 };
beforeEach(async () => {
  vi.resetModules(); vi.useFakeTimers(); vi.stubGlobal('window', globalThis);
  hw.connected = true; hw.send.mockReset().mockResolvedValue(good);
  hw.axis.mockReset().mockImplementation((axis) => axis === 'yaw' ? { ...good, ok: false } : good);
  motor = await import('../runtime/motor'); gate = await import('../runtime/outputGate');
  gate.setHardwareOutputsEnabled(true);
});
afterEach(() => { gate.setHardwareOutputsEnabled(false); vi.clearAllTimers(); vi.useRealTimers(); vi.unstubAllGlobals(); });
describe('motor follower lifecycle', () => {
  it('reports the requested tilt axis even when yaw is missing', async () => {
    expect((await motor.motorGoto(0, 'tilt')).ok).toBe(true);
    await motor.startFollow('tilt'); expect(motor.isFollowing('tilt')).toBe(true);
  });
  it('propagates command errors instead of returning cached success', async () => {
    hw.send.mockResolvedValueOnce({ ...good, ok: false, error: 'write failed' });
    expect(await motor.motorGoto(5, 'tilt')).toMatchObject({ ok: false, error: 'write failed' });
  });
  it('holds and cancels an approach when output is locked', async () => {
    let finish!: (result: typeof good) => void;
    hw.send.mockImplementationOnce(() => new Promise((resolve) => { finish = resolve; }));
    const starting = motor.startFollow('tilt');
    expect(motor.isFollowing('tilt')).toBe(true);
    gate.setHardwareOutputsEnabled(false);
    expect(hw.send).toHaveBeenCalledWith('hold', 'tilt', 0, false);
    finish(good); await starting;
    expect(motor.isFollowing('tilt')).toBe(false);
    await vi.advanceTimersByTimeAsync(1000);
    expect(hw.send.mock.calls.filter(([op]) => op === 'goal')).toHaveLength(1);
  });
  it('keeps polling until the last UI subscriber leaves', async () => {
    motor.startMotorPolling(); motor.startMotorPolling(); motor.stopMotorPolling();
    await vi.advanceTimersByTimeAsync(1100);
    const polls = hw.send.mock.calls.filter(([op]) => op === 'status').length;
    expect(polls).toBeGreaterThan(3);
    motor.stopMotorPolling(); await vi.advanceTimersByTimeAsync(2000);
    expect(hw.send.mock.calls.filter(([op]) => op === 'status')).toHaveLength(polls);
  });
});
