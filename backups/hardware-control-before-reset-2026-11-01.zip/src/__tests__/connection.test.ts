import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

let hw: typeof import('../runtime/hardware');
let gate: typeof import('../runtime/outputGate');
let serial: { getPorts: ReturnType<typeof vi.fn>; requestPort: ReturnType<typeof vi.fn>; addEventListener: ReturnType<typeof vi.fn> };
let events: Record<string, (event: unknown) => void>;

function makePort(ready = true) {
  let input: ReadableStreamDefaultController<Uint8Array>;
  const readable = new ReadableStream<Uint8Array>({ start(controller) { input = controller; } });
  const writer = { write: vi.fn(async (_bytes: Uint8Array) => {}), abort: vi.fn(async () => {}), releaseLock: vi.fn() };
  return {
    readable, writable: { getWriter: () => writer }, writer,
    open: vi.fn(async () => { if (ready) input.enqueue(new TextEncoder().encode('READY LIEU-HW fw=3\n')); }),
    close: vi.fn(async () => {}), getInfo: () => ({ usbVendorId: 0x2341 }),
    end: () => input.close(), text: (s: string) => input.enqueue(new TextEncoder().encode(s)),
  };
}

class FakeSocket {
  static instances: FakeSocket[] = [];
  readyState = 0; bufferedAmount = 0; binaryType = '';
  onmessage: ((e: { data: string }) => void) | null = null;
  onclose: (() => void) | null = null; onerror: (() => void) | null = null;
  send = vi.fn();
  constructor(public url: string) { FakeSocket.instances.push(this); }
  ready() { this.readyState = 1; this.onmessage?.({ data: 'READY LIEU-HW fw=3' }); }
  close() { this.readyState = 3; this.onclose?.(); }
}

beforeEach(async () => {
  vi.resetModules(); vi.useFakeTimers();
  vi.stubGlobal('window', globalThis);
  vi.stubGlobal('WebSocket', FakeSocket);
  FakeSocket.instances = [];
  events = {};
  serial = { getPorts: vi.fn(async () => []), requestPort: vi.fn(), addEventListener: vi.fn((name, fn) => { events[name] = fn; }) };
  vi.stubGlobal('navigator', { serial });
  hw = await import('../runtime/hardware');
  gate = await import('../runtime/outputGate');
});
afterEach(async () => {
  const closing = hw.disconnectHw();
  await vi.advanceTimersByTimeAsync(2500); await closing;
  vi.useRealTimers(); vi.unstubAllGlobals();
});

async function connect(port = makePort()) {
  serial.getPorts.mockResolvedValue([port]);
  const pending = hw.connectHw();
  await vi.advanceTimersByTimeAsync(1800); await pending;
  expect(hw.getHwStatus().connected).toBe(true);
  return port;
}

describe('USB lifecycle', () => {
  it('connects only once, detects EOF, closes locks and reconnects', async () => {
    const port = makePort(); serial.getPorts.mockResolvedValue([port]);
    const a = hw.connectHw(), b = hw.autoConnectHw();
    await vi.advanceTimersByTimeAsync(1800); await Promise.all([a, b]);
    expect(port.open).toHaveBeenCalledTimes(1);
    gate.setHardwareOutputsEnabled(true);
    port.end(); await vi.advanceTimersByTimeAsync(1000);
    expect(hw.getHwStatus().connected).toBe(false);
    expect(gate.hardwareOutputsEnabled()).toBe(false);
    expect(port.close).toHaveBeenCalledTimes(1);
    expect(port.writer.releaseLock).toHaveBeenCalledTimes(1);
    await connect();
  });
  it('rejects a port without LIEU firmware and remains retryable', async () => {
    serial.getPorts.mockResolvedValue([makePort(false)]);
    const pending = hw.connectHw();
    await vi.advanceTimersByTimeAsync(6000); await pending;
    expect(hw.getHwStatus()).toMatchObject({ connected: false, busy: false });
    expect(hw.getHwStatus().message).toContain('펌웨어');
    await connect();
  });
  it('cleans up when USB disappears before its reader can be acquired', async () => {
    const port = makePort();
    vi.spyOn(port.readable, 'getReader').mockImplementation(() => { throw new Error('Device disappeared'); });
    serial.getPorts.mockResolvedValue([port]);
    const pending = hw.connectHw();
    await vi.advanceTimersByTimeAsync(3000); await pending;
    expect(hw.getHwStatus()).toMatchObject({ connected: false, busy: false });
    expect(hw.getHwStatus().message).toContain('Device disappeared');
    expect(port.close).toHaveBeenCalledTimes(1);
    await connect();
  });
  it('bounds hung writes and does not replay queued commands after output lock', async () => {
    const port = await connect();
    gate.setHardwareOutputsEnabled(true);
    port.writer.write.mockImplementation(() => new Promise(() => {}));
    const first = hw.sendMotorCommand('goal', 'yaw', 10);
    await vi.advanceTimersByTimeAsync(0);
    const queued = hw.sendMotorCommand('goal', 'tilt', 5);
    gate.setHardwareOutputsEnabled(false);
    await vi.advanceTimersByTimeAsync(2500);
    expect((await first).ok).toBe(false);
    expect((await queued).ok).toBe(false);
    expect(hw.getHwStatus()).toMatchObject({ connected: false, busy: false });
    expect(port.writer.write.mock.calls.filter(([packet]) => packet[2] === 5 && packet[4] === 6)).toHaveLength(1);
    await connect();
  });
  it('ignores unplug of another port and cancels an in-progress connection', async () => {
    const port = await connect();
    events.disconnect({ target: makePort() });
    expect(hw.getHwStatus().connected).toBe(true);
    events.disconnect({ target: port });
    await vi.advanceTimersByTimeAsync(1000);
    const next = makePort(); serial.getPorts.mockResolvedValue([next]);
    const pending = hw.connectHw(); await vi.advanceTimersByTimeAsync(100);
    await hw.disconnectHw('cancelled');
    await vi.advanceTimersByTimeAsync(3000); await pending;
    expect(hw.getHwStatus()).toMatchObject({ connected: false, busy: false, message: 'cancelled' });
    await connect();
  });
  it('bounds a stalled open and closes a late handle', async () => {
    const port = makePort(); let finish!: () => void;
    port.open.mockImplementation(() => new Promise<void>((resolve) => { finish = resolve; }));
    serial.getPorts.mockResolvedValue([port]);
    const pending = hw.connectHw(); await vi.advanceTimersByTimeAsync(6500); await pending;
    expect(hw.getHwStatus().busy).toBe(false);
    finish(); await vi.advanceTimersByTimeAsync(0);
    expect(port.close).toHaveBeenCalledTimes(1);
  });
  it('waits for motor telemetry rather than assuming success after 60 ms', async () => {
    const port = await connect(); gate.setHardwareOutputsEnabled(true);
    let settled = false;
    const action = hw.sendMotorCommand('arm', 'tilt').then((result) => { settled = true; return result; });
    await vi.advanceTimersByTimeAsync(400);
    expect(settled).toBe(false);
    port.text('MOTOR axis=tilt found=1 torque=0 mode=4 profile=1 deg=0 hw=0 fault=7 front=1 limit=13\n');
    await vi.advanceTimersByTimeAsync(0);
    expect(await action).toMatchObject({ ok: false, fault: '보정 잠금 — 모든 모터 Torque OFF' });
  });
  it('times out missing motor readback without claiming success', async () => {
    await connect(); gate.setHardwareOutputsEnabled(true);
    const action = hw.sendMotorCommand('arm', 'tilt');
    await vi.advanceTimersByTimeAsync(1300);
    expect(await action).toMatchObject({ ok: false, error: 'tilt Arduino 응답 시간 초과' });
  });
  it('allows diagnostic INFO while locked and never sends a motion goal', async () => {
    const port = await connect();
    await hw.requestInfo(); await hw.sendMotorCommand('goal', 'yaw', 20);
    expect(port.writer.write.mock.calls.some(([packet]) => packet[2] === 3)).toBe(true);
    expect(port.writer.write.mock.calls.some(([packet]) => packet[2] === 5 && packet[4] === 6)).toBe(false);
  });
});

describe('Wi-Fi lifecycle', () => {
  it('requires READY, detects an unresponsive controller and reconnects locked', async () => {
    const pending = hw.connectWifiHw('192.168.0.160');
    const ws = FakeSocket.instances[0];
    expect(hw.getHwStatus().connected).toBe(false);
    ws.ready(); await pending;
    expect(hw.getHwStatus().connected).toBe(true);
    gate.setHardwareOutputsEnabled(true);
    await vi.advanceTimersByTimeAsync(7100);
    expect(hw.getHwStatus()).toMatchObject({ connected: false, busy: false });
    expect(gate.hardwareOutputsEnabled()).toBe(false);
    const retry = hw.connectWifiHw('192.168.0.160'); FakeSocket.instances[1].ready(); await retry;
    expect(hw.getHwStatus().connected).toBe(true);
    expect(gate.hardwareOutputsEnabled()).toBe(false);
  });
  it('aborts a pending handshake without a late timeout replacing the next connection', async () => {
    const pending = hw.connectWifiHw('192.168.0.160');
    await hw.disconnectHw('cancelled'); await pending;
    const retry = hw.connectWifiHw('192.168.0.161'); FakeSocket.instances[1].ready(); await retry;
    await vi.advanceTimersByTimeAsync(100);
    expect(hw.getHwStatus()).toMatchObject({ connected: true, transport: 'wifi' });
  });
  it('fails closed on buffered Wi-Fi writes instead of growing the queue', async () => {
    const pending = hw.connectWifiHw('192.168.0.160');
    const ws = FakeSocket.instances[0]; ws.ready(); await pending;
    gate.setHardwareOutputsEnabled(true); ws.bufferedAmount = 5000;
    expect(await hw.syncHardwareConfig()).toBe(false);
    await vi.advanceTimersByTimeAsync(0);
    expect(hw.getHwStatus().connected).toBe(false);
    expect(gate.hardwareOutputsEnabled()).toBe(false);
  });
});
