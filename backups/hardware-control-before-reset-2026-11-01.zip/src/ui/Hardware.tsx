import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { useStore } from '../store';
import { TILT_MOTOR, YAW_MOTOR, planAt, planYaw } from '../engine/motorPlan';
import { getMotorStatus, holdAllMotors, isFollowing, motorAct, motorBridgeUp, motorGoto, startFollow, startMotorPolling, stopFollow, stopMotorPolling, subscribeMotor, type Axis } from '../runtime/motor';
import { toast } from './ui-store';
import { autoConnectHw, connectHw, connectWifiHw, disconnectHw, getHwSettings, getHwStatus, hwSupported, probeEye, requestInfo, setHwSettings, subscribeHw, syncHardwareConfig, startHardwareEvents, type EyeLayout } from '../runtime/hardware';
import { hardwareOutputsEnabled, setHardwareOutputsEnabled, subscribeHardwareOutputs } from '../runtime/outputGate';
import { playWithFinalMonitor } from '../runtime/finalMonitor';
import { autoConnectU2D2, connectU2D2, disconnectU2D2, getU2D2Status, subscribeU2D2, u2d2Supported } from '../runtime/u2d2';

const useHw = () => {
  const st = useSyncExternalStore(subscribeHw, getHwStatus);
  const cfg = useSyncExternalStore(subscribeHw, getHwSettings);
  return { st, cfg };
};

const useOutputGate = () => useSyncExternalStore(subscribeHardwareOutputs, hardwareOutputsEnabled);
const useU2D2 = () => useSyncExternalStore(subscribeU2D2, getU2D2Status);

async function emergencyStopHardware() {
  setHardwareOutputsEnabled(false);
  await holdAllMotors();
  await Promise.all([disconnectU2D2('비상정지 · U2D2 연결 해제'), disconnectHw('비상정지 — 출력 잠김')]);
  toast('비상정지: 모터 Hold, 링 OFF, 눈은 기본표정 유지, 출력 잠금', 'warn', 6000);
}

async function returnToMotionEditMode() {
  setHardwareOutputsEnabled(false);
  await holdAllMotors();
  toast('모션 수정 모드 — 연결은 유지되고 실장치·TV·프로젝터 출력은 잠겼습니다.', 'ok', 5000);
}

export function HardwareModeBadge() {
  const enabled = useOutputGate();
  const st = useSyncExternalStore(subscribeHw, getHwStatus);
  const playing = useStore((s) => s.playing);
  const reason = !st.connected && !st.busy && st.message !== '연결 안 됨' ? st.message : '';
  return enabled
    ? <button className="badge hardware active" title="즉시 모터 Hold + LED·눈 Blank + 출력 잠금" onClick={() => void emergencyStopHardware()}>{playing ? '● HARDWARE PLAYING · E-STOP' : 'HARDWARE READY · E-STOP'}</button>
    : <><span className="badge hardware locked" title="연결은 유지할 수 있지만 실장치 출력은 잠겨 있습니다">{st.connected ? 'MOTION EDIT · OUTPUT LOCKED' : 'OUTPUT LOCKED'}</span>{reason && <span className="hardware-stop-reason" role="status" title={reason}>{reason}</span>}</>;
}

/** Live motor panel. Eyes, ring and DYNAMIXEL Shield share the active UNO R4 USB or Wi-Fi connection. */
/** One motor, one big button. The button does whatever the next step is: switch the motor on (after a confirmation), connect it to the slider, or stop. */
function MotorCard({ axis, compact = false }: { axis: Axis; compact?: boolean }) {
  const outputs = useOutputGate();
  useSyncExternalStore(subscribeMotor, () => JSON.stringify(getMotorStatus(axis)) + isFollowing(axis));
  useEffect(() => { startMotorPolling(); return stopMotorPolling; }, []);
  const m = getMotorStatus(axis), up = motorBridgeUp(), found = up && m.ok, armed = !!m.torque && m.mode === 4 && !!m.profile_ok, on = isFollowing(axis);
  const name = axis === 'yaw' ? 'Yaw · 시선 좌우' : axis === 'body' ? 'Body · 원기둥축 ±180°' : 'Tilt · 끄덕임', lim = m.limit_deg ?? (axis === 'yaw' ? YAW_MOTOR.limitDeg : axis === 'body' ? 180 : TILT_MOTOR.limitDeg);
  const say = async (p: Promise<{ ok: boolean; error?: string }>) => { const r = await p; if (!r.ok) toast(`모터: ${r.error ?? '거부됨'}`, 'warn'); return r.ok; };
  const state = !up ? ['off', 'Arduino 연결 안 됨'] : !found ? ['off', '쉴드에서 모터 찾는 중…'] : m.fault ? ['err', `오류: ${m.fault}`] : on ? ['on', `실물이 따라가는 중 · ${m.deg}°`] : armed ? ['ready', `준비됨 (토크 켜짐) · ${m.deg}°`] : ['off', `꺼짐 · 손으로 움직일 수 있음 · ${m.deg ?? '?'}°`];
  const start = async () => {
    if (!armed || m.needs_front) {
      const ask = m.needs_front
        ? '로봇이 지금 정확히 정면(0°)을 보고 있나요?\n\n현재 위치를 0°로 저장하고 토크를 켭니다. 켜지면 손으로 돌릴 수 없고, 스스로 움직이지는 않습니다.\n주변이 비었고 모터 전원에 손이 닿나요?'
        : `${axis === 'yaw' ? 'Yaw' : 'Tilt'} 모터의 토크를 켭니다. 켜지면 손으로 돌릴 수 없고, 스스로 움직이지는 않습니다. (최대 ±${lim}°, ${m.max_vel}°/s)\n주변이 비었고 모터 전원에 손이 닿나요?`;
      if (!window.confirm(ask)) return;
      if (!(await say(motorAct(m.needs_front ? 'setup' : 'arm', axis)))) return;
    }
    void startFollow(axis);
  };
  const label = m.fault ? '오류 해제' : on ? '■ 정지' : armed ? '▶ 슬라이더와 연결' : m.needs_front ? '▶ 정면을 맞췄어요 · 시작' : '▶ 시작 (토크 켜기)';
  return (
    <div className="mcard">
      <div className="mhead"><b>{name}</b><span className={'mdot ' + state[0]} />{state[1]}</div>
      {found && !compact && (
        <>
          <button disabled={!outputs && !on} className={'hwbig' + (on ? ' stop' : '')} onClick={() => (m.fault ? void motorAct('clear', axis) : on ? stopFollow(axis) : void start())}>{outputs ? label : '마스터 출력을 먼저 활성화하세요'}</button>
          {(axis === 'yaw' || axis === 'body') && m.needs_front && <small className="hwwarn">{axis === 'body' ? 'Body 축은 중심 raw와 감속비를 측정하기 전까지 펌웨어에서 Arm이 잠겨 있습니다.' : '먼저 로봇을 손으로 돌려서 정면을 보게 하세요. (모터 전원이 껐다 켜지면 정면을 다시 알려줘야 해요)'}</small>}
          <div className="mlinks">
            <button className="linkbtn" disabled={!m.torque} onClick={() => void say(motorAct('release', axis))}>토크 끄기 (손으로 움직이기)</button>
            <button className="linkbtn" disabled={!armed || on} onClick={() => void say(motorGoto(0, axis))}>0°로 이동</button>
            {axis === 'yaw' && <button className="linkbtn" disabled={on || m.needs_front} title="정면이 틀어졌을 때만" onClick={() => { if (window.confirm('로봇이 지금 정확히 정면(0°)을 보고 있나요? 현재 위치를 0°로 다시 저장합니다. 움직이지 않습니다.')) void say(motorAct('setup', 'yaw')); }}>정면 다시 잡기</button>}
          </div>
        </>
      )}
      {!up && <small className="hwwarn">1단계에서 UNO R4를 연결하세요.</small>}
    </div>
  );
}

/** Dry run of the yaw motor: shows what a slow, limited motor would do for this sequence. NOTHING is sent to any motor. */
function YawDryRun() {
  const seq = useStore((s) => s.seq), t = useStore((s) => s.tSec);
  const plan = useMemo(() => planYaw(seq), [seq]);
  const i = planAt(plan, t), c = YAW_MOTOR;
  return (
    <>
      <small className="hwsec">Yaw motor · dry run (nothing is sent)</small>
      <div className="hwrow"><small>limit ±{c.limitDeg}° · max {c.maxVel}°/s · accel {c.maxAcc}°/s²</small></div>
      <div className="hwrow">
        <small>now: sim {plan.sim[i].toFixed(1)}° → motor follows {plan.exec[i].toFixed(1)}° → raw {plan.raw[i]}</small>
      </div>
      <div className="hwrow">
        <small className={plan.clamped || plan.maxLagDeg > 5 ? 'hwwarn' : ''}>
          whole sequence: fastest ask {plan.maxSimVel.toFixed(0)}°/s · beyond ±{c.limitDeg}° in {(plan.clamped / plan.fps).toFixed(1)} s · biggest lag {plan.maxLagDeg.toFixed(0)}° at {plan.maxLagAtSec.toFixed(1)} s
        </small>
      </div>
    </>
  );
}

export function HardwareMenu() {
  const { st, cfg } = useHw();
  const u2 = useU2D2();
  useEffect(() => { startHardwareEvents(); void autoConnectU2D2(); }, []);
  const outputs = useOutputGate();
  const playing = useStore((s) => s.playing);
  const play = useStore((s) => s.play);
  const pause = useStore((s) => s.pause);
  const [open, setOpen] = useState(false);
  const [confirmingOutput, setConfirmingOutput] = useState(false);
  const usbBusy = st.busy && st.transport === 'usb';
  const wifiBusy = st.busy && !usbBusy;
  const [pos, setPos] = useState({ right: 12, top: 0 });
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const off = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    window.addEventListener('mousedown', off);
    return () => window.removeEventListener('mousedown', off);
  }, [open]);
  useEffect(() => { if (!st.connected || !u2.connected || outputs) setConfirmingOutput(false); }, [st.connected, u2.connected, outputs]);
  const num = (k: 'ringOffset' | 'maxScale' | 'budgetMa', f = 1) => (e: React.ChangeEvent<HTMLInputElement>) => setHwSettings({ [k]: Number(e.target.value) * f } as never);
  const enable = async () => {
    if (!st.connected) { toast('먼저 UNO R4를 연결하세요.', 'warn'); return; }
    if (!u2.connected) { toast('먼저 U2D2 모터 USB를 연결하세요.', 'warn'); return; }
    setHardwareOutputsEnabled(true);
    setConfirmingOutput(false);
    if (!(await syncHardwareConfig())) {
      setHardwareOutputsEnabled(false);
      toast('출력 설정 실패 · 연결 상태를 확인하세요', 'warn');
      return;
    }
    toast('실장치 구동 모드 준비 — Play를 눌러야 실장치·TV·프로젝터가 재생됩니다.', 'ok', 6000);
    await autoConnectHw();
  };
  return (
    <div className="exmenu" ref={ref}>
      <button className={'ico' + (outputs ? ' on' : '')} title="실장치 출력·상태·안전 컨트롤"
        onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); setPos({ right: Math.max(8, window.innerWidth - r.right), top: r.bottom + 6 }); setOpen((o) => !o); }}>
        {outputs ? '● ' : ''}하드웨어 <span className="caret">▾</span>
      </button>
      {open && (
        <div className="exlist hwpanel" style={{ right: pos.right, top: pos.top, left: 'auto' }}>
          <div className="hwtitle">
            <div><b>하드웨어 제어</b><small>연결 → 모드 선택 → 모터 준비 → 재생</small></div>
            <span className={'hwmode ' + (outputs ? 'live' : 'safe')}>{outputs ? playing ? '실장치 재생 중' : '실장치 준비' : st.connected ? '모션 수정' : '연결 대기'}</span>
          </div>

          <div className={'hwroute ' + (playing && outputs ? 'live' : '')}>
            <div><span className="hwroute-dot" /><b>현재 출력</b></div>
            <strong>{playing && outputs ? '실제 로봇 + TV + 프로젝터' : '웹 3D 프리뷰'}</strong>
            <small>{playing && outputs ? '웹 3D는 성능 보호를 위해 정지·디밍됩니다.' : outputs ? 'Play를 누르기 전까지 실제 장치는 움직이지 않습니다.' : '실제 장치 출력은 안전하게 잠겨 있습니다.'}</small>
          </div>

          <section className={'hwstep ' + (st.connected ? 'done' : 'current')}>
            <div className="hwstephead"><span className="hwstepnum">1</span><div><b>UNO R4 연결</b><small>연결만 해서는 모터가 움직이지 않습니다.</small></div><span className={'connpill ' + (st.connected ? 'on' : '')}>{st.connected ? '연결됨' : '연결 안 됨'}</span></div>
            {st.connected ? (
              <div className="hwconnected"><div><b>{st.transport === 'wifi' ? 'Wi-Fi' : 'USB'}</b><small>{st.message} · {st.frames} frames</small></div><button className="linkbtn" onClick={() => void disconnectHw()}>연결 끊기</button></div>
            ) : (
              <>
                <div className="wifi-connect">
                  <label>Arduino IP<input value={cfg.wifiHost} placeholder="192.168.0.160" onChange={(e) => setHwSettings({ wifiHost: e.target.value })} /></label>
                  <button className="hwprimary" disabled={st.busy || !cfg.wifiHost.trim()} onClick={() => void connectWifiHw()}>{wifiBusy ? 'Wi-Fi 연결 중…' : 'Wi-Fi 연결'}</button>
                </div>
                <div className="hwsecondary"><span>{st.message}</span>{st.busy && <button className="linkbtn" onClick={() => void disconnectHw('연결 취소됨')}>취소</button>}<button className="linkbtn" disabled={st.busy || !hwSupported()} onClick={() => void connectHw()}>{usbBusy ? 'USB 연결 중…' : 'USB로 연결'}</button></div>
                <small className="hwhelp">컴퓨터와 UNO가 같은 Wi-Fi에 있어야 합니다.</small>
              </>
            )}
          </section>

          <section className={'hwstep ' + (u2.connected ? 'done' : st.connected ? 'current' : 'disabled')}>
            <div className="hwstephead"><span className="hwstepnum">1B</span><div><b>U2D2 모터 연결</b><small>COM4 · Yaw/Tilt/Body 전용 · 3축 Sync Write</small></div><span className={'connpill ' + (u2.connected ? 'on' : '')}>{u2.connected ? '연결됨' : '연결 안 됨'}</span></div>
            {u2.connected ? (
              <div className="hwconnected"><div><b>U2D2 USB</b><small>{u2.message}</small></div><button className="linkbtn" onClick={() => void disconnectU2D2()}>연결 끊기</button></div>
            ) : (
              <div className="hwsecondary"><span>{u2.message}</span><button className="hwprimary" disabled={u2.busy || !u2d2Supported()} onClick={() => void connectU2D2()}>{u2.busy ? 'U2D2 연결 중…' : 'U2D2 연결'}</button></div>
            )}
            {!u2d2Supported() && <small className="hwwarn">U2D2 USB 연결은 Chrome/Edge에서만 지원됩니다.</small>}
          </section>

          <section className={'hwstep ' + (outputs ? 'done live' : st.connected && u2.connected ? 'current' : 'disabled')}>
            <div className="hwstephead"><span className="hwstepnum">2</span><div><b>작업 모드 선택</b><small>연결을 끊지 않고 언제든 전환할 수 있습니다.</small></div></div>
            <div className="hwchoices">
              <button className={'hwchoice ' + (!outputs ? 'selected' : '')} disabled={!st.connected || !u2.connected} onClick={() => void returnToMotionEditMode()}>
                <span>✎</span><div><b>모션 수정</b><small>웹 3D만 재생<br />실장치 출력 잠금</small></div>{!outputs && <em>선택됨</em>}
              </button>
              <button className={'hwchoice hardware ' + (outputs ? 'selected' : '')} disabled={!st.connected || !u2.connected} onClick={() => { if (!outputs) setConfirmingOutput(true); }}>
                <span>▶</span><div><b>실장치 실행</b><small>로봇 · TV · 프로젝터<br />웹 3D 정지·디밍</small></div>{outputs && <em>선택됨</em>}
              </button>
            </div>
            {outputs && <button className="estop wide" onClick={() => void emergencyStopHardware()}>■ 비상정지 · 출력 잠금 · 연결 끊기</button>}
            {!outputs && confirmingOutput && (
                <div className="hwconfirm">
                  <b>실장치 출력 전 안전 확인</b>
                  <ul>
                    <li>로봇 주변에 사람과 장애물이 없음</li>
                    <li>모터 전원과 비상정지 수단에 즉시 접근 가능</li>
                    <li>눈·링 전원 용량 확인</li>
                  </ul>
                  <div><button className="linkbtn" onClick={() => setConfirmingOutput(false)}>취소</button><button className="enable-output" onClick={() => void enable()}>확인 · 출력 활성화</button></div>
                </div>
              )}
          </section>

          <section className={'hwstep motors ' + (outputs ? 'current' : 'disabled')}>
            <div className="hwstephead"><span className="hwstepnum">3</span><div><b>모터 준비</b><small>{outputs ? '원하는 축만 시작하세요.' : '2단계를 완료하면 축별 시작 버튼이 열립니다.'}</small></div></div>
            {u2.connected ? <><MotorCard axis="yaw" compact={!outputs} /><MotorCard axis="tilt" compact={!outputs} /><MotorCard axis="body" compact={!outputs} /></> : <div className="hwempty">U2D2 연결을 기다리는 중</div>}
            <div className="railsafe"><span>—</span><div><b>Rail 모터</b><small>항상 Torque OFF · 이번 전시에서는 제어하지 않음</small></div><em>고정</em></div>
          </section>

          <section className={'hwstep hwrun ' + (outputs ? 'current' : 'disabled')}>
            <div className="hwstephead"><span className="hwstepnum">4</span><div><b>시나리오 실행</b><small>{outputs ? playing ? '실장치·TV·프로젝터가 타임라인을 실행 중입니다.' : '준비가 끝났다면 아래 버튼으로 시작하세요.' : '실장치 실행 모드를 먼저 선택하세요.'}</small></div></div>
            <button className={'hwplay ' + (playing ? 'playing' : '')} disabled={!outputs} onClick={() => playing ? pause() : playWithFinalMonitor()}>{playing ? '❚❚ 실장치 일시정지' : '▶ 실장치 재생 시작'}</button>
            <small className="hwplayhelp">타임라인의 Play/Space와 같은 버튼입니다. 정지하면 웹 프리뷰가 즉시 돌아옵니다.</small>
          </section>

          <details className="hwfold advanced">
            <summary>고급 설정 · 눈 / LED 링</summary>
            {!hwSupported() && <small className="hwwarn">USB 연결은 Chrome/Edge에서만 지원됩니다. Wi-Fi 연결은 다른 최신 브라우저에서도 사용할 수 있습니다.</small>}
            <small className="hwsec">Eyes (verify with the test dot)</small>
            <div className="hwrow">
              <label>layout <select value={cfg.layout} onChange={(e) => setHwSettings({ layout: e.target.value as EyeLayout })}><option value="adafruit">adafruit</option><option value="msb_left">msb_left</option><option value="lsb_left">lsb_left</option></select></label>
              <label><input type="checkbox" checked={cfg.flipX} onChange={(e) => setHwSettings({ flipX: e.target.checked })} /> flip X</label>
              <label><input type="checkbox" checked={cfg.flipY} onChange={(e) => setHwSettings({ flipY: e.target.checked })} /> flip Y</label>
              <label><input type="checkbox" checked={cfg.swap} onChange={(e) => setHwSettings({ swap: e.target.checked })} /> swap L/R</label>
            </div>
            <div className="hwrow">
              <button className="ico" disabled={!st.connected} onClick={() => void probeEye('L', 0, 0)}>L: top-left dot</button>
              <button className="ico" disabled={!st.connected} onClick={() => void probeEye('R', 0, 0)}>R: top-left dot</button>
              <button className="ico" disabled={!st.connected} onClick={() => void requestInfo()}>Ping</button>
            </div>
            <small className="hwsec">Ring</small>
            <div className="hwrow">
              <label>LED0 offset <input type="number" min={0} max={23} value={cfg.ringOffset} onChange={num('ringOffset')} style={{ width: 52 }} /></label>
              <label><input type="checkbox" checked={cfg.ringReverse} onChange={(e) => setHwSettings({ ringReverse: e.target.checked })} /> reverse</label>
            </div>
            <div className="hwrow">
              <label>max brightness % <input type="number" min={1} max={100} value={Math.round(cfg.maxScale * 100)} onChange={num('maxScale', 0.01)} style={{ width: 52 }} /></label>
              <label>budget mA <input type="number" min={50} max={2000} step={50} value={cfg.budgetMa} onChange={num('budgetMa')} style={{ width: 64 }} /></label>
            </div>
            <small className="hwsec">USB 전원일 때는 링 밝기를 낮게 유지하세요.</small>
          </details>
          <details className="hwfold advanced">
            <summary>고급 설정 · 시나리오 모터 안전 분석</summary>
            <YawDryRun />
          </details>
        </div>
      )}
    </div>
  );
}
