import { useStore } from '../store';
import type { DesiredState } from '../engine/types';
import { hardwareOutputsEnabled, setHardwareOutputsEnabled } from './outputGate';
import { withDeadline } from './asyncDeadline';

/** Live output to the UNO R4 + ROBOTIS DYNAMIXEL Shield over USB Web Serial or Wi-Fi WebSocket. */
export type EyeLayout = 'adafruit' | 'msb_left' | 'lsb_left';
export type HwSettings = {
  layout: EyeLayout; flipX: boolean; flipY: boolean; swap: boolean;
  addrL: number; addrR: number;
  ringOffset: number; ringReverse: boolean;
  maxScale: number; budgetMa: number;
  wifiHost: string;
};
export const DEFAULT_HW: HwSettings = { layout: 'adafruit', flipX: false, flipY: false, swap: false, addrL: 0x70, addrR: 0x71, ringOffset: 0, ringReverse: false, maxScale: 0.75, budgetMa: 400, wifiHost: '192.168.1.160' };

const SYNC = [0xaa, 0x55], T_FRAME = 1, T_CONFIG = 2, T_INFO = 3, T_BLANK = 4, T_MOTOR = 5, N = 24;
const MOTOR_OP = { arm: 1, hold: 2, release: 3, setup: 4, clear: 5, goal: 6, status: 7, bakedStart: 8, bakedStop: 9 } as const;
const MOTOR_AXIS = { yaw: 1, tilt: 2, body: 3 } as const;

export function packet(type: number, payload: ArrayLike<number> = []): Uint8Array {
  const body = [type, payload.length, ...Array.from(payload)];
  return Uint8Array.from([...SYNC, ...body, body.reduce((a, b) => a + b, 0) & 255]);
}

export function mapRow(row: number, layout: EyeLayout, flipX: boolean): number {
  const cols = Array.from({ length: 8 }, (_, c) => (row >> (7 - c)) & 1);
  if (flipX) cols.reverse();
  let out = 0;
  cols.forEach((on, c) => { if (on) out |= 1 << (layout === 'msb_left' ? 7 - c : layout === 'lsb_left' ? c : (c + 7) % 8); });
  return out;
}

/** Scale so the estimated draw (20 mA per channel at 255) stays within budget and max_scale. */
export function limitRing(ring: number[], maxScale: number, budgetMa: number): number[] {
  const total = ring.reduce((a, b) => a + b, 0);
  const scale = total ? Math.min(maxScale, budgetMa / ((total * 20) / 255)) : maxScale;
  return ring.map((b) => Math.floor(b * scale));
}

export type DeviceFrame = { l: number[]; r: number[]; bl: number; br: number; ring: number[] };

export function toDevice(s: DesiredState, c: HwSettings): DeviceFrame {
  const off = (i: number) => i < 0.03;
  const dim = (i: number) => Math.round(Math.min(1, Math.max(0, i)) * 15);
  let l = off(s.eyes.leftIntensity) ? new Array(8).fill(0) : [...s.eyes.left];
  let r = off(s.eyes.rightIntensity) ? new Array(8).fill(0) : [...s.eyes.right];
  let bl = dim(s.eyes.leftIntensity), br = dim(s.eyes.rightIntensity);
  if (c.swap) { [l, r] = [r, l]; [bl, br] = [br, bl]; }
  const eye = (rows: number[]) => { const m = rows.map((x) => mapRow(x, c.layout, c.flipX)); return c.flipY ? m.reverse() : m; };
  const g = s.ring24.brightness, phys = new Array(N * 4).fill(0), step = c.ringReverse ? -1 : 1;
  s.ring24.pixels.forEach((p, v) => {
    const q = (((step * v + c.ringOffset) % N) + N) % N;
    for (let k = 0; k < 4; k++) phys[q * 4 + k] = Math.round(p[k] * g);
  });
  return { l: eye(l), r: eye(r), bl, br, ring: limitRing(phys, c.maxScale, c.budgetMa) };
}

export const framePacket = (d: DeviceFrame) => packet(T_FRAME, [...d.l, ...d.r, d.bl, d.br, ...d.ring]);
/** Host already limits; the firmware keeps the same budget (+10 %) only as a backstop. */
export const configPacket = (c: HwSettings) => packet(T_CONFIG, [c.addrL, c.addrR, 255, (Math.round(c.budgetMa * 1.1) >> 8) & 255, Math.round(c.budgetMa * 1.1) & 255]);

// ---- connection (browser only) ---------------------------------------------------------------------------------------------
type Status = { connected: boolean; busy: boolean; message: string; frames: number; transport: 'usb' | 'wifi' | null };
export type ArduinoMotorStatus = { ok: boolean; error?: string; torque: boolean; mode: number; profile_ok: boolean; deg: number | null; hw_error: number; fault: string | null; needs_front: boolean; limit_deg: number; baked?: boolean };
export type ArduinoMotorAxis = 'yaw' | 'tilt' | 'body';
const emptyMotor = (axis: ArduinoMotorAxis): ArduinoMotorStatus => ({ ok: false, error: `${axis} motor not reported by Arduino`, torque: false, mode: 0, profile_ok: false, deg: null, hw_error: 0, fault: null, needs_front: false, limit_deg: axis === 'yaw' ? 90 : axis === 'body' ? 170 : 15 });
const motorRevision: Record<ArduinoMotorAxis, number> = { yaw: 0, tilt: 0, body: 0 };
let bakedRevision = 0, bakedActive = false;
let waitingMotors = 0;
let motorAxes: Record<ArduinoMotorAxis, ArduinoMotorStatus> = { yaw: emptyMotor('yaw'), tilt: emptyMotor('tilt'), body: emptyMotor('body') };
let port: any = null, writer: any = null, reader: any = null, socket: WebSocket | null = null, timer = 0, lastKey = '', lastSent = 0, readText = '';
let writeQueue: Promise<unknown> = Promise.resolve();
let generation = 0, pendingWrites = 0, framePending = false, probeGeneration = 0;
let readTask: Promise<void> | null = null, closing: Promise<void> | null = null;
let healthTimer = 0, lastReceived = 0, readySeen = false;
const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));
const isOpen = (ws: WebSocket | null) => ws?.readyState === 1;
let settings: HwSettings = loadSettings();
let status: Status = { connected: false, busy: false, message: '연결 안 됨', frames: 0, transport: null };
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((f) => f());

function loadSettings(): HwSettings {
  try {
    const saved = JSON.parse(localStorage.getItem('lieu.hw') ?? '{}');
    return normalizeSettings({ ...DEFAULT_HW, ...saved });
  } catch { return { ...DEFAULT_HW }; }
}
function normalizeSettings(c: HwSettings): HwSettings {
  const bounded = (v: number, lo: number, hi: number, fallback: number) => Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : fallback;
  return { ...c,
    maxScale: bounded(c.maxScale, 0, 1, DEFAULT_HW.maxScale),
    budgetMa: bounded(c.budgetMa, 50, 2000, DEFAULT_HW.budgetMa),
    ringOffset: Math.round(bounded(c.ringOffset, 0, 23, 0)),
  };
}
export const hwSupported = () => typeof navigator !== 'undefined' && 'serial' in navigator;
export const getHwSettings = () => settings;
export const getHwStatus = () => status;
export const getArduinoMotorStatus = (axis: ArduinoMotorAxis) => motorAxes[axis];
export function setHwSettings(p: Partial<HwSettings>) {
  settings = normalizeSettings({ ...settings, ...p });
  try { localStorage.setItem('lieu.hw', JSON.stringify(settings)); } catch { /* storage unavailable */ }
  lastKey = ''; // force a resend with the new mapping
  if ((writer || socket) && ('addrL' in p || 'addrR' in p || 'budgetMa' in p)) void send(configPacket(settings));
  emit();
}
export function subscribeHw(f: () => void) { listeners.add(f); return () => { listeners.delete(f); }; }
const setStatus = (p: Partial<Status>) => { status = { ...status, ...p }; emit(); };

async function send(bytes: Uint8Array, allowLocked = false): Promise<boolean> {
  const ws = socket, w = writer, session = generation;
  if ((!w && !isOpen(ws)) || (!allowLocked && !hardwareOutputsEnabled())) return false;
  if (isOpen(ws)) {
    // Do not buffer seconds of obsolete poses on a stalled Wi-Fi connection.
    if (ws!.bufferedAmount > 4096) {
      void disconnectHw('Wi-Fi 송신 정체 — 다시 연결하세요');
      return false;
    }
    try { ws!.send(bytes.slice().buffer); return true; }
    catch (e) { void disconnectHw(`Wi-Fi write failed: ${(e as Error).message}`); return false; }
  }
  if (pendingWrites >= 8) {
    void disconnectHw('USB 송신 정체 — 다시 연결하세요');
    return false;
  }
  pendingWrites++;
  const operation = writeQueue.then(async () => {
    // Re-check at execution time: queued goals must not survive a lock or reconnect.
    if (session !== generation || writer !== w || (!allowLocked && !hardwareOutputsEnabled())) return false;
    await withDeadline(w.write(bytes), 750, 'USB 응답 시간 초과');
    return true;
  });
  writeQueue = operation.catch(() => undefined);
  try { return await operation; }
  catch (e) {
    if (session === generation) void disconnectHw(`Write failed: ${(e as Error).message}`);
    return false;
  } finally { if (session === generation) pendingWrites--; }
}

const FAULTS: Record<number, string> = { 1: 'Arduino/DYNAMIXEL 통신 오류', 2: '모터 하드웨어 오류', 3: '안전 가동범위 초과', 4: '속도 프로파일 검증 실패', 5: '추종 오차 — 걸림 확인', 6: '정면 설정 필요', 7: '보정 잠금 — 모든 모터 Torque OFF' };
function onSerialLine(line: string) {
  const s = line.trim();
  if (s.startsWith('READY LIEU-HW') || s.startsWith('INFO LIEU-HW')) { readySeen = true; return; }
  if (s === 'BAKED started' || s === 'BAKED stopped' || s === 'BAKED not armed') {
    bakedActive = s === 'BAKED started';
    bakedRevision++;
    emit();
    return;
  }
  if (!s.startsWith('MOTOR ')) return;
  const kv = Object.fromEntries(s.split(/\s+/).slice(1).map((x) => x.split('=', 2)).filter((x) => x.length === 2));
  const axis: ArduinoMotorAxis | null = kv.axis === 'yaw' || kv.axis === 'tilt' || kv.axis === 'body' ? kv.axis : null;
  if (!axis) return;
  motorRevision[axis]++;
  if (kv.baked === '1' || kv.baked === '0') {
    const nextBaked = kv.baked === '1';
    bakedActive = nextBaked;
    // Every firmware status line is an authoritative acknowledgement. A
    // repeated baked=1 must still wake a pending START request when the short
    // textual ACK was lost by the Wi-Fi bridge.
    bakedRevision++;
  }
  const found = kv.found === '1', faultNo = Number(kv.fault || 0);
  motorAxes = { ...motorAxes, [axis]: {
    ok: found,
    error: found ? undefined : `${axis} motor not found on DYNAMIXEL Shield`,
    torque: kv.torque === '1', mode: Number(kv.mode || 0), profile_ok: kv.profile === '1',
    deg: found ? Number(kv.deg) : null, hw_error: Number(kv.hw || 0),
    fault: faultNo ? (FAULTS[faultNo] ?? `fault ${faultNo}`) : null,
    needs_front: kv.front !== '1', limit_deg: Number(kv.limit || (axis === 'yaw' ? 90 : axis === 'body' ? 170 : 15)),
    baked: kv.baked === '1',
  } };
  emit();
}

function onTransportText(text: string) {
  lastReceived = performance.now();
  readText += text;
  const lines = readText.split(/\r?\n/); readText = lines.pop() ?? '';
  lines.forEach(onSerialLine);
  // Wi-Fi READY messages have no newline; serial messages may arrive fragmented.
  if (readText.startsWith('READY LIEU-HW') && socket) { onSerialLine(readText); readText = ''; }
  if (readText.length > 8192) readText = ''; // malformed input cannot grow indefinitely
}

async function readLoop(p: any) {
  const decoder = new TextDecoder();
  let localReader: any = null;
  let reason = 'USB 읽기 종료 — 다시 연결하세요';
  try {
    localReader = p.readable.getReader();
    reader = localReader;
    while (port === p) {
      const { value, done } = await localReader.read();
      if (done || port !== p) break;
      onTransportText(decoder.decode(value, { stream: true }));
    }
  } catch (e) { reason = `USB 읽기 실패 · ${(e as Error).message}`; }
  finally {
    try { localReader?.releaseLock(); } catch { /* driver already closed */ }
    if (reader === localReader) reader = null;
    if (port === p) void disconnectHw(reason);
  }
}

function tick() {
  if ((!writer && !isOpen(socket)) || !hardwareOutputsEnabled() || !useStore.getState().playing || framePending) return;
  const d = toDevice(useStore.getState().evalNow(), settings);
  const key = [d.l, d.r, d.bl, d.br, d.ring].join('|');
  const now = performance.now();
  if (key !== lastKey || now - lastSent > 250) {
    const session = generation;
    framePending = true;
    void send(framePacket(d)).then((ok) => {
      if (session !== generation) return;
      if (ok) { lastKey = key; lastSent = performance.now(); status = { ...status, frames: status.frames + 1 }; }
    }).finally(() => { if (session === generation) framePending = false; });
  }
}

function startLinkTimers() {
  window.clearInterval(timer); window.clearInterval(healthTimer);
  timer = window.setInterval(tick, 1000 / 30);
  lastReceived = performance.now();
  healthTimer = window.setInterval(() => {
    if (!status.connected) return;
    if (performance.now() - lastReceived > 6000) {
      void disconnectHw('Arduino 응답 없음 — 연결과 전원을 확인하세요');
      return;
    }
    // Read-only heartbeat works while outputs are locked and the menu is closed.
    if (!waitingMotors) void send(motorCommandPacket('status', 'yaw'), true);
  }, 1000);
}

async function openPort(p: any, session: number) {
  port = p;
  let opened = false;
  try {
    const opening = p.open({ baudRate: 115200 });
    // If a timed-out driver opens late, close that abandoned handle.
    void opening.then(() => { if (session !== generation) void p.close().catch(() => undefined); }, () => undefined);
    await withDeadline(opening, 6000, 'USB 포트 열기 시간 초과');
    opened = true;
    if (session !== generation || port !== p) return;
    writer = p.writable.getWriter();
    setStatus({ message: 'USB Arduino 시작 응답 확인 중…' });
    readTask = readLoop(p);
    await sleep(1800);
    if (session !== generation) return;
    // An open USB port alone does not mean compatible firmware is running.
    for (let attempt = 0; attempt < 3 && !readySeen; attempt++) {
      if (!(await send(packet(T_INFO), true))) throw new Error('Arduino 확인 패킷 전송 실패');
      for (let n = 0; n < 10 && !readySeen && session === generation; n++) await sleep(100);
      if (session !== generation) return;
    }
    if (!readySeen) throw new Error('LIEU 펌웨어 응답 없음 · 보드/펌웨어를 확인하세요');
    lastKey = '';
    setStatus({ connected: true, busy: false, message: 'USB connected', frames: 0, transport: 'usb' });
    startLinkTimers();
  } catch (e) {
    if (!opened && session === generation) port = null;
    throw e;
  }
}

function beginConnection(transport: 'usb' | 'wifi', message: string) {
  generation++;
  readySeen = false; readText = ''; lastKey = ''; framePending = false;
  setHardwareOutputsEnabled(false);
  setStatus({ busy: true, connected: false, transport, message });
  return generation;
}

export async function connectHw() {
  if (!hwSupported()) { setStatus({ message: 'Web Serial needs Chrome or Edge' }); return; }
  startHardwareEvents();
  if (status.connected || status.busy || closing) return;
  const session = beginConnection('usb', 'USB 연결 준비 중…');
  try {
    const serial = (navigator as any).serial;
    // Reuse a port that Chrome has already granted to this origin. Calling
    // requestPort every time left the app looking frozen whenever Chrome's
    // chooser opened behind another window.
    const known = (await serial.getPorts()).find((p: any) => p.getInfo?.().usbVendorId === 0x2341);
    if (session !== generation) return;
    if (known) {
      setStatus({ message: '기존 Arduino USB 권한으로 연결 중…' });
      await openPort(known, session);
    } else {
      setStatus({ message: 'Chrome 포트 선택창에서 Arduino UNO R4를 선택하세요' });
      const selected = await serial.requestPort({ filters: [{ usbVendorId: 0x2341 }] });
      if (session !== generation) return;
      await openPort(selected, session);
    }
  } catch (e) {
    if (session !== generation) return;
    const err = e as Error;
    const message = err.name === 'NotFoundError'
      ? '포트 선택이 취소됨 · USB로 연결을 다시 눌러주세요'
      : err.name === 'NetworkError' || /open serial port|SerialPort.*open/i.test(err.message)
        ? 'USB 포트를 열 수 없습니다 · 다른 LIEU 탭/Arduino 시리얼 모니터를 닫고 다시 연결하세요'
        : `연결 실패 · ${err.message}`;
    await disconnectHw(message);
  }
}

function wifiUrl(host: string) {
  const clean = host.trim().replace(/^wss?:\/\//, '').replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/:81$/, '');
  if (!clean) throw new Error('Enter the Arduino IP address');
  if (typeof location !== 'undefined' && location.protocol === 'http:' && (location.hostname === '127.0.0.1' || location.hostname === 'localhost')) {
    return `ws://${location.host}/lieu-hw`;
  }
  return `ws://${clean}:81/`;
}

export async function connectWifiHw(host = settings.wifiHost) {
  if (status.connected || status.busy || closing) return;
  setHwSettings({ wifiHost: host.trim() });
  const session = beginConnection('wifi', 'UNO R4 응답을 기다리는 중…');
  let ws: WebSocket | null = null;
  try {
    ws = new WebSocket(wifiUrl(host));
    socket = ws;
    ws.binaryType = 'arraybuffer';
    await withDeadline(new Promise<void>((resolve, reject) => {
      ws!.onerror = () => reject(new Error('UNO R4의 81번 포트에 연결할 수 없음'));
      ws!.onclose = () => reject(new Error('UNO R4가 연결을 닫음'));
      ws!.onmessage = (e) => {
        if (typeof e.data !== 'string') return;
        if (e.data.startsWith('READY LIEU-HW')) { onTransportText(e.data + '\n'); resolve(); }
        else if (e.data.startsWith('BUSY ')) reject(new Error('다른 탭 연결이 남아 있음 — 다시 시도하세요'));
      };
    }), 7000, 'UNO R4 READY 응답 시간 초과');
    if (session !== generation || socket !== ws || !isOpen(ws)) return;
    // A WebSocket text event is a complete firmware reply. Some server builds
    // omit Print::println()'s trailing LF, so provide the line delimiter here.
    ws.onmessage = (e) => { if (socket === ws && typeof e.data === 'string') onTransportText(e.data + '\n'); };
    ws.onclose = () => { if (socket === ws) void disconnectHw('Wi-Fi disconnected'); };
    ws.onerror = () => { if (socket === ws) void disconnectHw('Wi-Fi 통신 오류'); };
    setStatus({ connected: true, busy: false, message: `UNO R4 준비 완료 · ${host.trim()}`, frames: 0, transport: 'wifi' });
    startLinkTimers();
  } catch (e) {
    if (session === generation) await disconnectHw(`Wi-Fi 연결 실패 · ${(e as Error).message}`);
  }
}

let autoStarted = false;
let serialEvents: any = null;
const onSerialConnect = () => void autoConnectHw();
const onSerialDisconnect = (event: any) => {
  if ((event.port ?? event.target) === port) void disconnectHw('USB 분리됨');
};
/** Install once even when the first connection is manual or no board is present. */
export function startHardwareEvents() {
  if (autoStarted || !hwSupported()) return;
  autoStarted = true;
  serialEvents = (navigator as any).serial;
  serialEvents.addEventListener('connect', onSerialConnect);
  serialEvents.addEventListener('disconnect', onSerialDisconnect);
}

export async function autoConnectHw() {
  startHardwareEvents();
  if (!hwSupported() || port || socket || status.busy || closing) return;
  const session = beginConnection('usb', 'USB 연결 확인 중…');
  try {
    const known = (await (navigator as any).serial.getPorts()).find((p: any) => p.getInfo?.().usbVendorId === 0x2341);
    if (session !== generation) return;
    if (!known) { setStatus({ busy: false, transport: null, message: '연결 안 됨' }); return; }
    await openPort(known, session);
  } catch (e) { if (session === generation) await disconnectHw(`Auto-connect failed: ${(e as Error).message}`); }
}

/** Apply output configuration after the user deliberately unlocks physical output. */
export async function syncHardwareConfig() {
  if (!status.connected || !hardwareOutputsEnabled()) return false;
  const ok = await send(configPacket(settings));
  lastKey = '';
  return ok;
}

export function disconnectHw(message = '연결 안 됨'): Promise<void> {
  if (closing) return closing;
  generation++; probeGeneration++;
  window.clearInterval(timer); window.clearInterval(healthTimer); timer = 0; healthTimer = 0;
  const p = port, w = writer, r = reader, reading = readTask, ws = socket, queued = writeQueue;
  // Detach first, before awaiting any driver. Old callbacks cannot touch the next link.
  port = null; writer = null; reader = null; socket = null; readTask = null;
  writeQueue = Promise.resolve(); pendingWrites = 0; framePending = false; readText = '';
  setHardwareOutputsEnabled(false);
  motorAxes = { yaw: emptyMotor('yaw'), tilt: emptyMotor('tilt'), body: emptyMotor('body') };
  setStatus({ connected: false, busy: true, message, transport: null });
  closing = (async () => {
    await Promise.resolve();
    try {
      if (isOpen(ws)) { try { ws!.send(packet(T_BLANK).slice().buffer); } catch { /* disconnected */ } }
      try { ws?.close(); } catch { /* disconnected */ }
      if (w) {
        try {
          await withDeadline(queued.then(() => w.write(packet(T_BLANK))), 200, 'blank timeout');
        } catch { try { await withDeadline(w.abort(), 200, 'abort timeout'); } catch { /* driver stalled */ } }
        try { w.releaseLock(); } catch { /* driver stalled */ }
      }
      try { if (r) await withDeadline(r.cancel(), 300, 'read cancel timeout'); } catch { /* disconnected */ }
      try { if (reading) await withDeadline(reading, 300, 'read loop timeout'); } catch { /* disconnected */ }
      try { if (p) await withDeadline(p.close(), 500, 'close timeout'); } catch { /* disconnected */ }
    } finally { closing = null; setStatus({ busy: false }); }
  })();
  return closing;
}

/** Single lit eye pixel (virtual row/col) to calibrate the eye mapping. */
export async function probeEye(side: 'L' | 'R', row: number, col: number) {
  if (!hardwareOutputsEnabled() || !status.connected) return;
  const session = generation, probe = ++probeGeneration;
  const rows = new Array(8).fill(0); rows[row] = 1 << (7 - col);
  const z = new Array(8).fill(0);
  const m = (a: number[]) => { const o = a.map((x) => mapRow(x, settings.layout, settings.flipX)); return settings.flipY ? o.reverse() : o; };
  const [l, r] = side === 'L' ? [rows, z] : [z, rows];
  const [pl, pr] = settings.swap ? [r, l] : [l, r];
  const hold = window.setInterval(() => { if (session === generation && probe === probeGeneration) void send(packet(T_FRAME, [...m(pl), ...m(pr), 15, 15, ...new Array(96).fill(0)])); }, 100);
  window.clearInterval(timer); // pause live output while probing
  await new Promise((res) => setTimeout(res, 1500));
  window.clearInterval(hold);
  if (session === generation && probe === probeGeneration && status.connected) timer = window.setInterval(tick, 1000 / 30);
}
export const requestInfo = () => send(packet(T_INFO), true);

export type MotorCommandName = keyof typeof MOTOR_OP;
export function motorCommandPacket(name: MotorCommandName, axis: ArduinoMotorAxis = 'yaw', deg = 0, follow = false): Uint8Array {
  const centiDeg = Math.round(deg * 100);
  const payload = name === 'goal'
    ? [MOTOR_OP[name], MOTOR_AXIS[axis], (centiDeg >> 8) & 255, centiDeg & 255, follow ? 1 : 0]
    : [MOTOR_OP[name], name === 'bakedStart' || name === 'bakedStop' ? 0 : MOTOR_AXIS[axis]];
  return packet(T_MOTOR, payload);
}

/** Reliable motor command over the active UNO R4 USB or Wi-Fi link. Firmware re-checks limits, profile and torque. */
export async function sendMotorCommand(name: MotorCommandName, axis: ArduinoMotorAxis = 'yaw', deg = 0, follow = false): Promise<ArduinoMotorStatus> {
  if (name === 'goal' && (!Number.isFinite(deg) || Math.abs(deg) > 327.67)) return { ...emptyMotor(axis), error: 'Invalid motor goal' };
  const safety = name === 'hold' || name === 'release' || name === 'status';
  if (!status.connected) return { ...emptyMotor(axis), error: 'Arduino is not connected' };
  if (!safety && !hardwareOutputsEnabled()) return { ...getArduinoMotorStatus(axis), ok: false, error: 'hardware outputs are locked' };
  const session = generation, revision = motorRevision[axis], bakedBefore = bakedRevision;
  // Subscribe before writing: Wi-Fi replies can arrive before write() settles.
  let unsubscribe = () => {}, timeout: ReturnType<typeof setTimeout> | undefined;
  const response = name === 'goal' ? null : new Promise<boolean>((resolve) => {
    waitingMotors++;
    const check = () => {
      if (session !== generation) resolve(false);
      else if ((name === 'bakedStart' || name === 'bakedStop') && bakedRevision !== bakedBefore) resolve(true);
      else if (motorRevision[axis] !== revision) resolve(true);
    };
    unsubscribe = subscribeHw(check);
    timeout = setTimeout(() => resolve(false), name === 'bakedStart' || name === 'bakedStop' ? 4000 : 1200);
  });
  try {
    if (!(await send(motorCommandPacket(name, axis, deg, follow), safety))) return { ...emptyMotor(axis), error: 'Arduino write failed' };
    if (session !== generation) return { ...emptyMotor(axis), error: 'Arduino disconnected' };
    if (name === 'bakedStart' || name === 'bakedStop') {
      // Motor polling is paused while a command is waiting, so explicitly
      // request authoritative state. This recovers when the Wi-Fi bridge
      // drops the firmware's short textual START/STOP acknowledgement.
      await new Promise((resolve) => setTimeout(resolve, 80));
      await send(motorCommandPacket('status', 'yaw'), true);
    }
    if (response && !(await response)) return { ...emptyMotor(axis), error: `${axis} Arduino 응답 시간 초과` };
    const current = getArduinoMotorStatus(axis);
    if (name === 'bakedStart') return bakedActive
      ? { ...current, ok: true }
      : { ...current, ok: false, error: 'Firmware rejected baked motion: motors are not armed' };
    if (name === 'bakedStop') return { ...current, ok: !bakedActive, error: bakedActive ? 'Firmware did not stop baked motion' : undefined };
    if (name !== 'status' && name !== 'hold' && name !== 'release' && current.fault) return { ...current, ok: false, error: current.fault };
    if ((name === 'arm' || name === 'setup') && (!current.torque || !current.profile_ok || current.needs_front)) return { ...current, ok: false, error: `${axis} motor did not arm` };
    return current;
  } finally {
    unsubscribe(); clearTimeout(timeout);
    if (response) waitingMotors--;
  }
}

if (import.meta.hot) import.meta.hot.dispose(() => {
  serialEvents?.removeEventListener('connect', onSerialConnect);
  serialEvents?.removeEventListener('disconnect', onSerialDisconnect);
  void disconnectHw('코드 갱신 — 다시 연결하세요');
});
