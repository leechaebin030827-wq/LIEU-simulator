// LIEU firmware for Arduino UNO R4 (Minima / WiFi).
// USB is always available; UNO R4 WiFi also accepts one browser controller over WebSocket.
// Outputs: eyes, ring and three DYNAMIXEL motors on a ROBOTIS Shield.
// Eyes: 2x HT16K33 8x8 on I2C (SDA=A4, SCL=A5). Ring: 24 NeoPixel RGBW on D6 (330 ohm in series, common GND).
// Shield: Serial1 on D0/D1, direction D2. Libraries: Adafruit NeoPixel + Dynamixel2Arduino >= 0.8.1.
#include <Wire.h>
#include <Adafruit_NeoPixel.h>
#include "motor_shield.h"

#if defined(ARDUINO_UNOWIFIR4)
#include <WiFiS3.h>
#include <WebSocketsServer.h>
#include "arduino_secrets.h"
#define LIEU_HAS_WIFI 1
#else
#define LIEU_HAS_WIFI 0
#endif

#define PIN_RING   6
#define RING_COUNT 24
#define LED_TYPE   (NEO_GRBW + NEO_KHZ800)   // SK6812 RGBW. Plain WS2812 RGB ring: NEO_GRB + NEO_KHZ800 (W byte is then ignored)
#define BAUD       115200
#define WATCHDOG_MS 2000                     // no frame for this long -> everything off

static const uint8_t SYNC0 = 0xAA, SYNC1 = 0x55;
enum : uint8_t { T_FRAME = 1, T_CONFIG = 2, T_INFO = 3, T_BLANK = 4, T_MOTOR = 5 };
static const uint8_t FRAME_LEN = 8 + 8 + 2 + RING_COUNT * 4;

Adafruit_NeoPixel ring(RING_COUNT, PIN_RING, LED_TYPE);
LieuMotorShield motors;

#if LIEU_HAS_WIFI
WebSocketsServer wifiSocket(81);
int16_t wifiController = -1;
bool wifiServerStarted = false;
uint32_t wifiRetryAt = 0;
uint32_t wifiStatusAt = 0;
uint32_t wifiPollAt = 0;
uint8_t wifiState = WL_IDLE_STATUS;
#endif

uint8_t addr[2] = {0x70, 0x71};              // left, right; overwritten by the host CONFIG packet
uint8_t dimNow[2] = {255, 255};
uint8_t maxScale = 64;                       // 0..255 hard cap on ring brightness (backstop; the host already limits)
uint16_t budgetMa = 400;                     // estimated ring current cap (20 mA per channel at 255)
uint32_t lastFrameMs = 0;
bool dark = true;
uint32_t nFrames = 0, nBad = 0, nI2cErr = 0;   // shown by INFO, for bring-up
uint8_t ringFrom[RING_COUNT * 4] = {0};
uint8_t ringTarget[RING_COUNT * 4] = {0};
uint8_t ringDisplayed[RING_COUNT * 4] = {0};
uint32_t ringBlendAt = 0, ringDrawAt = 0;

// ---- HT16K33 -------------------------------------------------------------------------------------------------------------
void htCmd(uint8_t a, uint8_t c) { Wire.beginTransmission(a); Wire.write(c); Wire.endTransmission(); }

void htInit(uint8_t a) { htCmd(a, 0x21); htCmd(a, 0x81); htCmd(a, 0xE0 | 15); }

void htShow(uint8_t side, const uint8_t* rows, uint8_t dim) {
  if (dim != dimNow[side]) { htCmd(addr[side], 0xE0 | (dim & 15)); dimNow[side] = dim; }
  Wire.beginTransmission(addr[side]);
  Wire.write((uint8_t)0x00);
  for (uint8_t r = 0; r < 8; r++) { Wire.write(rows[r]); Wire.write((uint8_t)0); }   // 8x8 backpack: row r at register 2r
  if (Wire.endTransmission() != 0) nI2cErr++;
}

bool htPresent(uint8_t a) { Wire.beginTransmission(a); return Wire.endTransmission() == 0; }

// ---- Ring ----------------------------------------------------------------------------------------------------------------
void ringShow(const uint8_t* px) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < RING_COUNT * 4; i++) sum += px[i];
  uint32_t scale = maxScale;                                  // /255
  uint32_t estMa = (sum * 20UL / 255UL) * scale / 255UL;
  if (estMa > budgetMa) scale = scale * budgetMa / estMa;
  for (uint8_t i = 0; i < RING_COUNT; i++) {
    const uint8_t* p = px + i * 4;
    ring.setPixelColor(i, ring.Color(p[0] * scale / 255, p[1] * scale / 255, p[2] * scale / 255, p[3] * scale / 255));
  }
  ring.show();
}

// Host frames arrive at the video's 30 fps cadence. Blend only the RGBW ring
// between those targets at ~100 Hz so slow breaths, waves and fades do not
// appear as 30 discrete brightness steps. Eye bitmaps intentionally remain
// frame-held because blinks and expressions are authored as discrete shapes.
void pumpRingBlend(bool force = false) {
  const uint32_t now = millis();
  if (!force && now - ringDrawAt < 10) return;
  ringDrawAt = now;
  const uint32_t age = now - ringBlendAt;
  const uint16_t u = age >= 34 ? 256 : (uint16_t)(age * 256UL / 34UL);
  for (uint8_t i = 0; i < RING_COUNT * 4; i++) {
    ringDisplayed[i] = (uint8_t)(((uint16_t)ringFrom[i] * (256 - u) + (uint16_t)ringTarget[i] * u) >> 8);
  }
  ringShow(ringDisplayed);
}

void setRingTarget(const uint8_t* px) {
  pumpRingBlend(true);
  memcpy(ringFrom, ringDisplayed, sizeof(ringFrom));
  memcpy(ringTarget, px, sizeof(ringTarget));
  ringBlendAt = millis();
}

// ---- Output --------------------------------------------------------------------------------------------------------------
// Neutral 3x6 round eyes. Safety blanking must hold motors and turn the ring
// off, but LIEU's face stays alive through disconnects, watchdogs and E-STOP.
static const uint8_t IDLE_EYE_L[8] = {0, 16, 56, 56, 56, 56, 16, 0};
static const uint8_t IDLE_EYE_R[8] = {0, 8, 28, 28, 28, 28, 8, 0};

void blankAll() {
  uint8_t z[RING_COUNT * 4] = {0};
  htShow(0, IDLE_EYE_L, 13); htShow(1, IDLE_EYE_R, 13);
  memcpy(ringFrom, z, sizeof(ringFrom));
  memcpy(ringTarget, z, sizeof(ringTarget));
  memcpy(ringDisplayed, z, sizeof(ringDisplayed));
  ringShow(z);
  dark = true;
}

void onFrame(const uint8_t* p) {
  htShow(0, p, p[16]);
  htShow(1, p + 8, p[17]);
  setRingTarget(p + 18);
  lastFrameMs = millis();
  nFrames++;
  dark = false;
}

void onConfig(const uint8_t* p, uint8_t n, Print& out = Serial) {
  if (n < 5) return;
  addr[0] = p[0]; addr[1] = p[1];
  maxScale = p[2];
  budgetMa = ((uint16_t)p[3] << 8) | p[4];
  dimNow[0] = dimNow[1] = 255;
  htInit(addr[0]); htInit(addr[1]);
  out.print(F("CONFIG eyeL=0x")); out.print(addr[0], HEX);
  out.print(F(" eyeR=0x")); out.print(addr[1], HEX);
  out.print(F(" scale=")); out.print(maxScale);
  out.print(F(" budget_mA=")); out.println(budgetMa);
  if (addr[0] == addr[1]) out.println(F("WARN both eyes share one I2C address: set A0/A1/A2 pads on one board"));
}

void onInfo(Print& out = Serial) {
  out.print(F("INFO LIEU-HW fw=3 board=UNO-R4 shield=DYNAMIXEL ring=")); out.print(RING_COUNT);
  out.print(F(" eyeL=0x")); out.print(addr[0], HEX); out.print(htPresent(addr[0]) ? F(":ok") : F(":MISSING"));
  out.print(F(" eyeR=0x")); out.print(addr[1], HEX); out.println(htPresent(addr[1]) ? F(":ok") : F(":MISSING"));
  out.print(F("I2C scan:"));
  for (uint8_t a = 0x08; a < 0x78; a++) if (htPresent(a)) { out.print(F(" 0x")); out.print(a, HEX); }
  out.println();
  out.print(F("frames=")); out.print(nFrames);
  out.print(F(" bad=")); out.print(nBad);
  out.print(F(" i2cErr=")); out.println(nI2cErr);
#if LIEU_HAS_WIFI
  out.print(F("WIFI state=")); out.print(wifiState);
  if (wifiState == WL_CONNECTED) { out.print(F(" ip=")); out.print(WiFi.localIP()); }
  out.println(F(" websocket_port=81"));
#endif
  motors.printStatus(out);
}

void dispatchPacket(uint8_t type, const uint8_t* payload, uint8_t len, Print& out) {
  if (type == T_FRAME && len == FRAME_LEN) onFrame(payload);
  else if (type == T_CONFIG) onConfig(payload, len, out);
  else if (type == T_INFO) onInfo(out);
  else if (type == T_BLANK) { motors.holdAll(); blankAll(); }
  else if (type == T_MOTOR) motors.command(payload, len, out);
}

// ---- Serial parser (AA 55 | type | len | payload | sum) --------------------------------------------------------------------
void pump() {
  static uint8_t st = 0, type, len, idx, buf[255];
  static uint8_t sum;
  // Yield to Wi-Fi and motor watchdogs even if the host continuously fills USB.
  uint16_t processed = 0;
  while (Serial.available() && processed++ < 256) {
    uint8_t b = Serial.read();
    switch (st) {
      case 0: st = (b == SYNC0) ? 1 : 0; break;
      case 1: st = (b == SYNC1) ? 2 : (b == SYNC0 ? 1 : 0); break;
      case 2: type = b; sum = b; st = 3; break;
      case 3: len = b; sum += b; idx = 0; st = len ? 4 : 5; break;
      case 4: buf[idx++] = b; sum += b; if (idx == len) st = 5; break;
      case 5:
        if (b == sum) {
          dispatchPacket(type, buf, len, Serial);
        } else { nBad++; Serial.println(F("ERR checksum")); }
        st = 0; break;
    }
  }
}

#if LIEU_HAS_WIFI
class StringSink : public Print {
 public:
  String text;
  size_t write(uint8_t c) override { text += (char)c; return 1; }
};

bool dispatchWirePacket(const uint8_t* p, size_t n, Print& out) {
  if (n < 5 || p[0] != SYNC0 || p[1] != SYNC1) return false;
  const uint8_t type = p[2], len = p[3];
  if (n != (size_t)len + 5) return false;
  uint8_t sum = type + len;
  for (uint8_t i = 0; i < len; i++) sum += p[4 + i];
  if (sum != p[4 + len]) return false;
  dispatchPacket(type, p + 4, len, out);
  return true;
}

void wifiEvent(uint8_t num, WStype_t type, uint8_t* payload, size_t length) {
  if (type == WStype_CONNECTED) {
    if (wifiController >= 0 && wifiController != num) {
      // A browser reload can leave the old socket half-open for a while. The newest
      // deliberate connection wins, but all physical output is made safe first.
      const uint8_t oldController = (uint8_t)wifiController;
      motors.holdAll();
      blankAll();
      wifiSocket.sendTXT(oldController, "REPLACED by a new controller");
      wifiSocket.disconnect(oldController);
    }
    wifiController = num;
    wifiSocket.sendTXT(num, "READY LIEU-HW fw=3 UNO-R4-WIFI");
  } else if (type == WStype_DISCONNECTED) {
    if (wifiController == num) {
      wifiController = -1;
      motors.holdAll();
      blankAll();
    }
  } else if (type == WStype_BIN && wifiController == num) {
    StringSink reply;
    if (!dispatchWirePacket(payload, length, reply)) {
      nBad++;
      wifiSocket.sendTXT(num, "ERR packet");
    } else if (reply.text.length()) {
      wifiSocket.sendTXT(num, reply.text);
    }
  }
}

void startWifiServer(IPAddress ip) {
  if (wifiServerStarted || ip == IPAddress(0, 0, 0, 0)) return;
  wifiSocket.begin();
  wifiSocket.onEvent(wifiEvent);
  // The editor also renders WebGL/video; allow brief UI stalls without dropping a
  // healthy controller. Motor and light watchdogs remain independent and stricter.
  wifiSocket.enableHeartbeat(5000, 3000, 3);
  wifiServerStarted = true;
  Serial.print(F("WIFI READY ssid=")); Serial.print(LIEU_WIFI_SSID);
  Serial.print(F(" ip=")); Serial.print(WiFi.localIP());
  Serial.println(F(" websocket_port=81"));
}

void beginWifi() {
  // WiFiS3 otherwise busy-waits up to 10 seconds for association inside begin(),
  // starving USB and motor watchdog servicing. Poll association from loop().
  WiFi.setTimeout(0);
  if (WiFi.status() == WL_NO_MODULE) { Serial.println(F("WIFI MISSING")); return; }
  Serial.print(F("WIFI connecting to ")); Serial.println(LIEU_WIFI_SSID);
  WiFi.begin(LIEU_WIFI_SSID, LIEU_WIFI_PASS);
  wifiRetryAt = millis() + 10000;
}

void pumpWifi() {
  const uint32_t now = millis();
  const bool checkLink = (int32_t)(now - wifiPollAt) >= 0;
  if (checkLink) {
    wifiPollAt = now + 500;
    wifiState = WiFi.status();
  }
  if (wifiState == WL_CONNECTED) {
    if (wifiServerStarted) { wifiSocket.loop(); return; }
    if (!checkLink) return;
    IPAddress ip = WiFi.localIP();
    if (ip == IPAddress(0, 0, 0, 0)) {
      if ((int32_t)(millis() - wifiStatusAt) >= 0) {
        wifiStatusAt = millis() + 3000;
        Serial.println(F("WIFI waiting for DHCP address"));
      }
      return;
    }
    startWifiServer(ip);
    wifiSocket.loop();
    return;
  }
  if (wifiServerStarted) {
    wifiSocket.close();
    wifiServerStarted = false;
    wifiController = -1;
    motors.holdAll();
    blankAll();
  }
  if ((int32_t)(millis() - wifiRetryAt) >= 0) {
    wifiRetryAt = millis() + 10000;
    WiFi.begin(LIEU_WIFI_SSID, LIEU_WIFI_PASS);
  }
}
#endif

void setup() {
  Serial.begin(BAUD);
  motors.begin();
  Wire.begin();
  Wire.setClock(400000);
  ring.begin();
  htInit(addr[0]); htInit(addr[1]);
  blankAll();
  // boot blink so the wiring can be checked without the host: ring LED 0 and one dot per eye
  uint8_t dot[8] = {0, 0, 0, 0x18, 0x18, 0, 0, 0}, px[RING_COUNT * 4] = {0};
  px[3] = 255;
  htShow(0, dot, 4); htShow(1, dot, 4); ringShow(px);
  delay(400);
  blankAll();
  uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 1500) {}
  Serial.println(F("READY LIEU-HW fw=3 UNO-R4 DYNAMIXEL-SHIELD"));
  motors.printStatus();
#if LIEU_HAS_WIFI
  beginWifi();
#endif
}

void loop() {
  pump();
#if LIEU_HAS_WIFI
  pumpWifi();
#endif
  motors.tick();
  if (!dark) pumpRingBlend();
  if (!dark && millis() - lastFrameMs > WATCHDOG_MS) blankAll();
}
