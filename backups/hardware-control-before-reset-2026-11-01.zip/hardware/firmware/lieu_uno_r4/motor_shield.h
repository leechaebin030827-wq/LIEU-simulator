#pragma once

// ROBOTIS DYNAMIXEL Shield on UNO R4.
// USB Serial remains reserved for the LIEU host protocol. The shield uses
// Serial1 (D0/D1) and its half-duplex direction pin D2.
#include <Dynamixel2Arduino.h>
#include "final_motor_bake.h"

using namespace ControlTableItem;

static const uint32_t DXL_BAUD = 115200;
static const float DXL_PROTOCOL = 2.0;
static const uint8_t DXL_DIR_PIN = 2;
static const uint8_t MOTOR_YAW = 1, MOTOR_TILT = 2, MOTOR_BODY = 3, MOTOR_RAIL = 4;
static const uint16_t MOTOR_WATCHDOG_MS = 600;
// Goal Position (X-series control table address 116) is transmitted for all
// axes that changed during the same control slice in one broadcast packet.
// At 115200 baud a three-axis packet takes about 3 ms on the wire, so 100 Hz
// leaves ample bus time for watchdogs and low-rate readback without making one
// motor wait behind the other two.
static const uint16_t MOTOR_SYNC_ADDR = 116;
static const uint16_t MOTOR_SYNC_LEN = 4;
static const uint16_t MOTOR_CONTROL_INTERVAL_MS = 10;
// At 60 deg/s an axis can legitimately move ~27 deg between its round-robin
// readbacks. Keep the tracking latch above that stale-sample distance; hard
// position limits and the DYNAMIXEL hardware alarm remain independent.
static const float TRACK_ERROR_DEG = 40.0f;
// Commissioning mode: every axis is torque-off at boot and no command may energize or move it.
// Change to false only after the user has completed and verified each axis calibration.
static const bool COMMISSIONING_LOCK = false;

enum MotorOp : uint8_t {
  M_ARM = 1, M_HOLD = 2, M_RELEASE = 3, M_SETUP_FRONT = 4,
  M_CLEAR = 5, M_GOAL = 6, M_STATUS = 7
  , M_BAKED_START = 8, M_BAKED_STOP = 9
};

enum MotorFault : uint8_t {
  MF_NONE = 0, MF_COMM = 1, MF_HARDWARE = 2, MF_RANGE = 3,
  MF_PROFILE = 4, MF_TRACKING = 5, MF_FRONT = 6, MF_CALIBRATION = 7
};

struct MotorAxis {
  const char* name;
  uint8_t id;
  float limitDeg;
  uint32_t profileVel;
  uint32_t profileAcc;
  bool found;
  bool torque;
  bool profileOk;
  bool needsFront;
  bool calibrated;
  uint8_t mode;
  uint8_t hwError;
  uint8_t fault;
  int32_t presentRaw;
  int32_t goalRaw;
  float presentDeg;
  float goalDeg;
  bool following;
  uint32_t lastGoalMs;
};

class LieuMotorShield {
 public:
  LieuMotorShield() : dxl(Serial1, DXL_DIR_PIN) {
    // Velocity/acceleration caps match the calculated smoothstep peaks of
    // 08 Final Exhibition: yaw 60, tilt 25, body 60 deg/s. Position limits and
    // ID 4's permanent torque-off remain independent safety boundaries.
    // The measured positive stop is beyond +100 robot degrees. Scenario 08
    // deliberately starts at +90; its negative extreme remains only -70.
    // The authored browser trajectory already carries smooth acceleration.
    // A non-zero servo profile restarted its ramp at every streamed goal and
    // produced visible stop-start motion, especially on the short tilt axis.
    yaw = {"yaw", MOTOR_YAW, 90.0f, 275, 20, false, false, false, false, true, 0, 0, 0, 0, 0, 0, 0, false, 0};
    tilt = {"tilt", MOTOR_TILT, 15.0f, 31, 4, false, false, false, false, true, 0, 0, 0, 0, 0, 0, 0, false, 0};
    body = {"body", MOTOR_BODY, 170.0f, 154, 8, false, false, false, false, true, 0, 0, 0, 0, 0, 0, 0, false, 0};
  }

  void begin() {
    dxl.begin(DXL_BAUD);
    dxl.setPortProtocolVersion(DXL_PROTOCOL);
    initSyncWrite();
    delay(30);
    // Broadcast release is the first bus command: scanning must never energize an axis.
    dxl.torqueOff(DXL_BROADCAST_ID);
    dxl.torqueOff(MOTOR_RAIL);
    delay(20);
    scanCount = dxl.ping(DXL_BROADCAST_ID, scanInfo, sizeof(scanInfo) / sizeof(scanInfo[0]));
    for (uint8_t i = 0; i < scanCount; i++) dxl.torqueOff(scanInfo[i].id);
    discover(yaw);
    discover(tilt);
    discover(body);
    // Repeat after discovery so a controller reset can never inherit an energized axis.
    torqueOff(yaw); torqueOff(tilt); torqueOff(body);
  }

  void tick() {
    const uint32_t now = millis();
    tickBaked(now);
    flushGoals(now);
    if (now - lastRailReleaseMs >= 1000) {
      lastRailReleaseMs = now;
      dxl.torqueOff(MOTOR_RAIL); // ID 4 Rail is intentionally never armed or positioned.
    }
    if (now - lastPollMs >= (bakedActive ? 500UL : 150UL)) {
      lastPollMs = now;
      // Poll one axis per beat. Polling all three here while the UI also asks
      // for status can overrun the 115200-baud DYNAMIXEL bus and makes the
      // later axes look disconnected even though they are present.
      if (pollAxis == 0) poll(yaw);
      else if (pollAxis == 1) poll(tilt);
      else poll(body);
      pollAxis = (pollAxis + 1) % 3;
    }
    // tickBaked() may write a goal and stamp lastGoalMs a few milliseconds
    // after `now` was captured above. Reusing the older timestamp makes the
    // unsigned subtraction in watchdog() underflow and immediately Hold the
    // brand-new goal. Sample time again after all writes/polls.
    const uint32_t watchdogNow = millis();
    watchdog(yaw, watchdogNow); watchdog(tilt, watchdogNow); watchdog(body, watchdogNow);
  }

  void command(const uint8_t* p, uint8_t n, Print& out = Serial) {
    if (n < 2) return;
    const uint8_t op = p[0], axisId = p[1];
    if (op == M_BAKED_START) { startBaked(); out.println(bakedActive ? F("BAKED started") : F("BAKED not armed")); return; }
    if (op == M_BAKED_STOP) { stopBaked(); out.println(F("BAKED stopped")); return; }
    if (bakedActive && op == M_GOAL) return; // stale browser goals cannot disturb local playback
    MotorAxis* a = axisId == MOTOR_YAW ? &yaw : axisId == MOTOR_TILT ? &tilt : axisId == MOTOR_BODY ? &body : nullptr;
    // Wi-Fi asks one axis at a time so every WebSocket text frame stays small.
    // axisId 0 remains the full USB/diagnostic report.
    if (op == M_STATUS) {
      if (a) { poll(*a); printOne(*a, out); }
      else printStatus(out);
      return;
    }
    if (axisId == 0 && (op == M_HOLD || op == M_RELEASE)) {
      act(yaw, op, 0, false); act(tilt, op, 0, false); act(body, op, 0, false); printStatus(out); return;
    }
    if (!a) return;
    int16_t centiDeg = 0;
    bool follow = false;
    if (op == M_GOAL) {
      if (n < 5) return;
      centiDeg = (int16_t)(((uint16_t)p[2] << 8) | p[3]);
      follow = p[4] != 0;
    }
    act(*a, op, centiDeg / 100.0f, follow);
    // Streaming goals arrive at up to 30 Hz per axis. Reading five registers and
    // returning a status frame for every goal exceeds the 115200-baud bus budget.
    // tick() still polls all axes every 250 ms; M_STATUS returns explicit readback.
    // Arm/setup/hold/release continue to return their immediate verified state.
    if (op == M_GOAL) return;
    poll(*a);
    printOne(*a, out);
  }

  void holdAll() { act(yaw, M_HOLD, 0, false); act(tilt, M_HOLD, 0, false); act(body, M_HOLD, 0, false); }

  void printStatus(Print& out = Serial) {
    printScan(out);
    poll(yaw); poll(tilt); poll(body);
    printOne(yaw, out); printOne(tilt, out); printOne(body, out);
  }

 private:
  struct SyncGoalData { int32_t goalPosition; } __attribute__((packed));
  Dynamixel2Arduino dxl;
  DYNAMIXEL::InfoFromPing_t scanInfo[16];
  uint8_t scanCount = 0;
  MotorAxis yaw, tilt, body;
  DYNAMIXEL::InfoSyncWriteInst_t syncWriteInfo;
  DYNAMIXEL::XELInfoSyncWrite_t syncWriteXels[3];
  SyncGoalData syncGoalData[3];
  uint8_t pendingGoalMask = 0;
  uint32_t lastControlMs = 0;
  // Latest physical-front calibration made on the installed motor. The prior
  // -709 value belonged to an earlier extended-position origin; restoring it
  // after a firmware upload misread the real +87 pose as +142 degrees.
  // Physical front confirmed by the user on 2026-11-01. The previous centre
  // made the neutral pose look about 10 degrees to the right.
  int32_t yawCenterRaw = 3107;  // physical zero confirmed by the user, torque off, 2026-11-01
  int32_t tiltCenterRaw = 2050; // physical level confirmed by the user, torque off, 2026-11-01
  int32_t bodyCenterRaw = 2296; // physical zero confirmed by the user, torque off, 2026-11-01
  uint32_t lastPollMs = 0;
  uint32_t lastRailReleaseMs = 0;
  uint8_t pollAxis = 0;
  uint32_t yawTrackErrorAt = 0, tiltTrackErrorAt = 0, bodyTrackErrorAt = 0;
  bool bakedActive = false;
  uint32_t bakedStartedAt = 0;
  uint16_t bakedFrame = 0xffff;
  int16_t bakedLast[3] = {32767, 32767, 32767};

  uint32_t& trackErrorAt(MotorAxis& a) {
    return a.id == MOTOR_YAW ? yawTrackErrorAt : a.id == MOTOR_TILT ? tiltTrackErrorAt : bodyTrackErrorAt;
  }

  uint8_t axisIndex(const MotorAxis& a) const {
    return a.id == MOTOR_YAW ? 0 : a.id == MOTOR_TILT ? 1 : 2;
  }

  void initSyncWrite() {
    syncWriteInfo.packet.p_buf = nullptr; // use the library's internal packet buffer
    syncWriteInfo.packet.is_completed = false;
    syncWriteInfo.addr = MOTOR_SYNC_ADDR;
    syncWriteInfo.addr_length = MOTOR_SYNC_LEN;
    syncWriteInfo.p_xels = syncWriteXels;
    syncWriteInfo.xel_count = 0;
    syncWriteInfo.is_info_changed = true;
  }

  void cancelPending(MotorAxis& a) {
    pendingGoalMask &= (uint8_t)~(1U << axisIndex(a));
  }

  void stageGoal(MotorAxis& a, int32_t raw, float deg, bool follow) {
    const uint8_t i = axisIndex(a);
    syncGoalData[i].goalPosition = raw;
    pendingGoalMask |= (uint8_t)(1U << i);
    a.goalRaw = raw;
    a.goalDeg = deg;
    a.following = follow;
    a.lastGoalMs = millis();
  }

  void flushGoals(uint32_t now) {
    if (!pendingGoalMask || now - lastControlMs < MOTOR_CONTROL_INTERVAL_MS) return;
    lastControlMs = now;
    MotorAxis* axes[3] = {&yaw, &tilt, &body};
    uint8_t sentMask = 0;
    syncWriteInfo.xel_count = 0;
    for (uint8_t i = 0; i < 3; i++) {
      MotorAxis& a = *axes[i];
      const uint8_t bit = (uint8_t)(1U << i);
      if (!(pendingGoalMask & bit) || !a.found || !a.torque || a.fault) continue;
      const uint8_t slot = syncWriteInfo.xel_count++;
      syncWriteXels[slot].id = a.id;
      syncWriteXels[slot].p_data = (uint8_t*)&syncGoalData[i].goalPosition;
      sentMask |= bit;
    }
    // Discard goals for axes that became unavailable before this slice.
    pendingGoalMask &= (uint8_t)~sentMask;
    if (!syncWriteInfo.xel_count) { pendingGoalMask = 0; return; }
    syncWriteInfo.is_info_changed = true;
    if (dxl.syncWrite(&syncWriteInfo)) return;
    // A broadcast write has no per-servo reply. A local transmit failure means
    // none of these targets can be trusted, so latch the affected axes safe.
    for (uint8_t i = 0; i < 3; i++) {
      if (!(sentMask & (1U << i))) continue;
      axes[i]->fault = MF_COMM;
      axes[i]->following = false;
      dxl.torqueOff(axes[i]->id);
      axes[i]->torque = false;
    }
  }

  bool allArmed() const {
    return yaw.torque && tilt.torque && body.torque && yaw.profileOk && tilt.profileOk && body.profileOk;
  }

  void applyBakedFrame(uint16_t frame) {
    const int16_t y = FINAL_MOTOR_FRAMES[frame][0];
    const int16_t t = FINAL_MOTOR_FRAMES[frame][1];
    const int16_t b = FINAL_MOTOR_FRAMES[frame][2];
    // Re-sending an identical position restarts the DYNAMIXEL velocity
    // profile. Only changed targets are written, so holds remain genuinely
    // still and the servo can finish each move.
    if (y != bakedLast[0]) { act(yaw, M_GOAL, y / 100.0f, true); bakedLast[0] = y; }
    if (t != bakedLast[1]) { act(tilt, M_GOAL, t / 100.0f, true); bakedLast[1] = t; }
    if (b != bakedLast[2]) { act(body, M_GOAL, b / 100.0f, true); bakedLast[2] = b; }
  }

  void startBaked() {
    if (!allArmed()) { bakedActive = false; return; }
    bakedActive = true;
    bakedStartedAt = millis();
    bakedFrame = 0;
    bakedLast[0] = bakedLast[1] = bakedLast[2] = 32767;
    applyBakedFrame(0);
  }

  void stopBaked() {
    bakedActive = false;
    bakedFrame = 0xffff;
    bakedLast[0] = bakedLast[1] = bakedLast[2] = 32767;
    safeHold(yaw); safeHold(tilt); safeHold(body);
  }

  void tickBaked(uint32_t now) {
    if (!bakedActive) return;
    const uint32_t elapsed = (now - bakedStartedAt) % FINAL_MOTOR_DURATION_MS;
    const uint32_t calculated = elapsed * FINAL_MOTOR_FPS / 1000UL;
    const uint16_t frame = calculated < FINAL_MOTOR_FRAME_COUNT ? (uint16_t)calculated : FINAL_MOTOR_FRAME_COUNT - 1;
    // Quantize the 20 Hz source to a deterministic 10 Hz servo command rate.
    // The former 4 Hz/250 ms cadence was visible as stepping in fast authored
    // motion even though the trajectory itself was smooth.
    // exact multiple of five. Wi-Fi and DYNAMIXEL transactions can make one
    // loop take longer than a 50 ms source frame; the old modulo check then
    // skipped that waypoint permanently and could leave every motor at frame 0.
    const uint16_t waypoint = (frame / 2) * 2;
    if (waypoint == bakedFrame) return;
    bakedFrame = waypoint;
    // A 300 ms trajectory horizon prevents the servo from arriving and
    // braking between waypoints. All data is local flash, so this look-ahead is
    // deterministic and independent of Wi-Fi timing.
    uint16_t target = waypoint + 6;
    if (target >= FINAL_MOTOR_FRAME_COUNT) target = FINAL_MOTOR_FRAME_COUNT - 1;
    applyBakedFrame(target);
  }

  void printScan(Print& out) {
    out.print(F("DXL_SCAN count=")); out.println(scanCount);
    for (uint8_t i = 0; i < scanCount; i++) {
      out.print(F("DXL_FOUND id=")); out.print(scanInfo[i].id);
      out.print(F(" model=")); out.print(scanInfo[i].model_number);
      out.print(F(" firmware=")); out.print(scanInfo[i].firmware_version);
      const float raw = dxl.getPresentPosition(scanInfo[i].id, UNIT_RAW);
      out.print(F(" raw="));
      if (isfinite(raw)) out.print(lroundf(raw)); else out.print(F("ERR"));
      out.print(F(" torque="));
      out.println((int32_t)dxl.readControlTableItem(TORQUE_ENABLE, scanInfo[i].id) == 1 ? 1 : 0);
    }
  }

  int32_t readItem(uint8_t item, uint8_t id) { return (int32_t)dxl.readControlTableItem(item, id); }

  void discover(MotorAxis& a) {
    a.found = dxl.ping(a.id);
    if (!a.found) return;
    // First action after every successful ping is release. Never retain torque across an Arduino reset.
    dxl.torqueOff(a.id);
    a.torque = false;
    if (COMMISSIONING_LOCK || !a.calibrated) a.fault = MF_CALIBRATION;
    else if (a.fault == MF_COMM) a.fault = MF_NONE;
    poll(a);
  }

  void torqueOff(MotorAxis& a) {
    cancelPending(a);
    a.following = false;
    if (a.found) dxl.torqueOff(a.id);
    a.torque = false;
    if (COMMISSIONING_LOCK) a.fault = MF_CALIBRATION;
  }

  int32_t toRaw(const MotorAxis& a, float deg) const {
    if (a.id == MOTOR_YAW) return lroundf(yawCenterRaw + deg * 71.6556f);
    if (a.id == MOTOR_BODY) return lroundf(bodyCenterRaw + deg * 40.0611f);
    return deg >= 0 ? lroundf(tiltCenterRaw - deg * (214.0f / 15.0f))
                    : lroundf(tiltCenterRaw + (-deg) * (200.0f / 15.0f));
  }

  float toDeg(const MotorAxis& a, int32_t raw) const {
    if (a.id == MOTOR_YAW) return (raw - yawCenterRaw) / 71.6556f;
    if (a.id == MOTOR_BODY) return (raw - bodyCenterRaw) / 40.0611f;
    return raw <= tiltCenterRaw ? (tiltCenterRaw - raw) * (15.0f / 214.0f)
                                : -(raw - tiltCenterRaw) * (15.0f / 200.0f);
  }

  bool writeItem(uint8_t item, uint8_t id, int32_t value) {
    if (!dxl.writeControlTableItem(item, id, value)) return false;
    return true;
  }

  void poll(MotorAxis& a) {
    if (!a.found) { discover(a); return; }
    float raw = dxl.getPresentPosition(a.id, UNIT_RAW);
    // One noisy packet must not permanently poison an otherwise healthy axis.
    if (!isfinite(raw) || dxl.getLastLibErrCode() != DXL_LIB_OK) {
      delay(2);
      raw = dxl.getPresentPosition(a.id, UNIT_RAW);
    }
    if (!isfinite(raw) || dxl.getLastLibErrCode() != DXL_LIB_OK) { a.found = false; a.fault = MF_COMM; return; }
    a.presentRaw = lroundf(raw);
    a.presentDeg = toDeg(a, a.presentRaw);
    a.torque = readItem(TORQUE_ENABLE, a.id) == 1;
    a.mode = (uint8_t)readItem(OPERATING_MODE, a.id);
    a.hwError = (uint8_t)readItem(HARDWARE_ERROR_STATUS, a.id);
    const int32_t pv = readItem(PROFILE_VELOCITY, a.id);
    a.profileOk = pv > 0 && (uint32_t)pv <= a.profileVel;
    if (a.hwError) { a.fault = MF_HARDWARE; safeHold(a); }
    else if (a.fault == MF_COMM) a.fault = MF_NONE;
  }

  bool prepareAndArm(MotorAxis& a) {
    cancelPending(a);
    if (COMMISSIONING_LOCK) { torqueOff(a); return false; }
    if (!a.found || a.fault) return false;
    if (!a.calibrated) { a.fault = MF_CALIBRATION; return false; }
    if (a.needsFront) { a.fault = MF_FRONT; return false; }
    if (!a.torque) {
      dxl.torqueOff(a.id);
      if (!dxl.setOperatingMode(a.id, OP_EXTENDED_POSITION)) { a.fault = MF_COMM; return false; }
      if (readItem(OPERATING_MODE, a.id) != 4) { a.fault = MF_PROFILE; return false; }
    } else if (readItem(OPERATING_MODE, a.id) != 4) {
      a.fault = MF_PROFILE; return false;
    }
    if (!writeItem(PROFILE_ACCELERATION, a.id, a.profileAcc) ||
        !writeItem(PROFILE_VELOCITY, a.id, a.profileVel)) { a.fault = MF_COMM; return false; }
    const int32_t readVel = readItem(PROFILE_VELOCITY, a.id);
    if (readVel <= 0 || (uint32_t)readVel > a.profileVel ||
        (uint32_t)readItem(PROFILE_ACCELERATION, a.id) != a.profileAcc) { a.fault = MF_PROFILE; return false; }
    const float hereF = dxl.getPresentPosition(a.id, UNIT_RAW);
    if (!isfinite(hereF) || dxl.getLastLibErrCode() != DXL_LIB_OK) { a.fault = MF_COMM; return false; }
    const int32_t here = lroundf(hereF);
    if (!dxl.setGoalPosition(a.id, here, UNIT_RAW)) { a.fault = MF_COMM; return false; }
    if (readItem(GOAL_POSITION, a.id) != here) { a.fault = MF_COMM; return false; }
    delay(20);
    const float verifyF = dxl.getPresentPosition(a.id, UNIT_RAW);
    if (!isfinite(verifyF) || dxl.getLastLibErrCode() != DXL_LIB_OK || abs(lroundf(verifyF) - here) > 4) { a.fault = MF_COMM; return false; }
    if (readItem(HARDWARE_ERROR_STATUS, a.id) != 0) { a.fault = MF_HARDWARE; return false; }
    if (!dxl.torqueOn(a.id)) { a.fault = MF_COMM; return false; }
    if (readItem(TORQUE_ENABLE, a.id) != 1) { a.fault = MF_COMM; return false; }
    a.torque = true; a.profileOk = true; a.goalRaw = here; a.goalDeg = toDeg(a, here);
    return true;
  }

  void safeHold(MotorAxis& a) {
    cancelPending(a);
    a.following = false;
    if (!a.found || !a.torque) return;
    const int32_t here = lroundf(dxl.getPresentPosition(a.id, UNIT_RAW));
    dxl.setGoalPosition(a.id, here, UNIT_RAW);
    a.goalRaw = here; a.goalDeg = toDeg(a, here);
  }

  void act(MotorAxis& a, uint8_t op, float deg, bool follow) {
    if (!a.found && op != M_CLEAR) { a.fault = MF_COMM; return; }
    if (op == M_CLEAR) {
      poll(a);
      if (COMMISSIONING_LOCK || !a.calibrated) { torqueOff(a); a.fault = MF_CALIBRATION; }
      else if (!a.hwError) a.fault = MF_NONE;
      return;
    }
    if (op == M_RELEASE) {
      cancelPending(a);
      a.following = false;
      if (a.found) dxl.torqueOff(a.id);
      a.torque = false;
      return;
    }
    if (op == M_HOLD) { safeHold(a); return; }
    if (op == M_SETUP_FRONT) {
      if (COMMISSIONING_LOCK) { torqueOff(a); return; }
      const float raw = dxl.getPresentPosition(a.id, UNIT_RAW);
      if (!isfinite(raw) || dxl.getLastLibErrCode() != DXL_LIB_OK) { a.fault = MF_COMM; return; }
      if (a.id == MOTOR_YAW) yawCenterRaw = lroundf(raw);
      else if (a.id == MOTOR_TILT) tiltCenterRaw = lroundf(raw);
      else bodyCenterRaw = lroundf(raw);
      a.needsFront = false;
      a.fault = MF_NONE;
      prepareAndArm(a);
      return;
    }
    if (op == M_ARM) { prepareAndArm(a); return; }
    if (COMMISSIONING_LOCK) { torqueOff(a); return; }
    if (op != M_GOAL || a.fault || !a.torque || !a.profileOk || a.needsFront) return;
    if (deg < -a.limitDeg || deg > a.limitDeg) { a.fault = MF_RANGE; safeHold(a); return; }
    const int32_t raw = toRaw(a, deg);
    stageGoal(a, raw, deg, follow);
  }

  void watchdog(MotorAxis& a, uint32_t now) {
    uint32_t& errorAt = trackErrorAt(a);
    if (!a.found || !a.torque || !a.following) { errorAt = 0; return; }
    if (now - a.lastGoalMs > MOTOR_WATCHDOG_MS) { safeHold(a); return; }
    if (fabsf(a.goalDeg - a.presentDeg) > TRACK_ERROR_DEG) {
      // Present position is sampled round-robin and can be hundreds of
      // milliseconds older than the newest streamed goal. A single large
      // difference is therefore normal during fast multi-axis motion. Only a
      // sustained mismatch indicates a genuinely stalled mechanism.
      if (!errorAt) errorAt = now;
      else if (now - errorAt > 1200) { a.fault = MF_TRACKING; safeHold(a); errorAt = 0; }
    } else errorAt = 0;
  }

  void printOne(const MotorAxis& a, Print& out) {
    out.print(F("MOTOR axis=")); out.print(a.name);
    out.print(F(" found=")); out.print(a.found ? 1 : 0);
    out.print(F(" torque=")); out.print(a.torque ? 1 : 0);
    out.print(F(" mode=")); out.print(a.mode);
    out.print(F(" profile=")); out.print(a.profileOk ? 1 : 0);
    out.print(F(" deg=")); out.print(a.presentDeg, 2);
    out.print(F(" raw=")); out.print(a.presentRaw);
    out.print(F(" vel=")); out.print((int32_t)dxl.readControlTableItem(PRESENT_VELOCITY, a.id));
    out.print(F(" hw=")); out.print(a.hwError);
    out.print(F(" fault=")); out.print(a.fault);
    out.print(F(" front=")); out.print(a.needsFront ? 0 : 1);
    out.print(F(" limit=")); out.print(a.limitDeg, 1);
    out.print(F(" baked=")); out.print(bakedActive ? 1 : 0);
    out.print(F(" baked_frame=")); out.print(bakedFrame);
    out.print(F(" baked_yaw=")); out.print(bakedLast[0]);
    out.print(F(" goal_cmd=")); out.print(a.goalRaw);
    out.print(F(" goal_reg=")); out.print(readItem(GOAL_POSITION, a.id));
    out.println();
  }
};
