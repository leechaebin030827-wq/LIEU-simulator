#pragma once

// ROBOTIS DYNAMIXEL Shield on UNO R4.
// USB Serial remains reserved for the LIEU host protocol. The shield uses
// Serial1 (D0/D1) and its half-duplex direction pin D2.
#include <Dynamixel2Arduino.h>

using namespace ControlTableItem;

static const uint32_t DXL_BAUD = 115200;
static const float DXL_PROTOCOL = 2.0;
static const uint8_t DXL_DIR_PIN = 2;
static const uint8_t MOTOR_YAW = 1, MOTOR_TILT = 2, MOTOR_BODY = 3;
static const uint16_t MOTOR_WATCHDOG_MS = 600;
static const float TRACK_ERROR_DEG = 15.0f;
// Commissioning mode: every axis is torque-off at boot and no command may energize or move it.
// Change to false only after the user has completed and verified each axis calibration.
static const bool COMMISSIONING_LOCK = true;

enum MotorOp : uint8_t {
  M_ARM = 1, M_HOLD = 2, M_RELEASE = 3, M_SETUP_FRONT = 4,
  M_CLEAR = 5, M_GOAL = 6, M_STATUS = 7
};

enum MotorFault : uint8_t {
  MF_NONE = 0, MF_COMM = 1, MF_HARDWARE = 2, MF_RANGE = 3,
  MF_PROFILE = 4, MF_TRACKING = 5, MF_FRONT = 6, MF_CALIBRATION = 7
};

struct MotorAxis {
  const char* name;
  uint8_t id;
  float limitDeg;
  uint32_t profileVel;
  uint32_t profileAcc;
  bool found;
  bool torque;
  bool profileOk;
  bool needsFront;
  bool calibrated;
  uint8_t mode;
  uint8_t hwError;
  uint8_t fault;
  int32_t presentRaw;
  int32_t goalRaw;
  float presentDeg;
  float goalDeg;
  bool following;
  uint32_t lastGoalMs;
};

class LieuMotorShield {
 public:
  LieuMotorShield() : dxl(Serial1, DXL_DIR_PIN) {
    yaw = {"yaw", MOTOR_YAW, 70.0f, 279, 30, false, false, false, true, true, 0, 0, 0, 0, 0, 0, 0, false, 0};
    tilt = {"tilt", MOTOR_TILT, 13.0f, 26, 6, false, false, false, false, true, 0, 0, 0, 0, 0, 0, 0, false, 0};
    body = {"body", MOTOR_BODY, 170.0f, 1, 1, false, false, false, true, true, 0, 0, MF_CALIBRATION, 0, 0, 0, 0, false, 0};
  }

  void begin() {
    dxl.begin(DXL_BAUD);
    dxl.setPortProtocolVersion(DXL_PROTOCOL);
    delay(30);
    // Broadcast release is the first bus command: scanning must never energize an axis.
    dxl.torqueOff(DXL_BROADCAST_ID);
    delay(20);
    scanCount = dxl.ping(DXL_BROADCAST_ID, scanInfo, sizeof(scanInfo) / sizeof(scanInfo[0]));
    for (uint8_t i = 0; i < scanCount; i++) dxl.torqueOff(scanInfo[i].id);
    discover(yaw);
    discover(tilt);
    discover(body);
    // Repeat after discovery so a controller reset can never inherit an energized axis.
    torqueOff(yaw); torqueOff(tilt); torqueOff(body);
  }

  void tick() {
    const uint32_t now = millis();
    if (now - lastPollMs >= 250) {
      lastPollMs = now;
      poll(yaw); poll(tilt); poll(body);
    }
    watchdog(yaw, now); watchdog(tilt, now); watchdog(body, now);
  }

  void command(const uint8_t* p, uint8_t n, Print& out = Serial) {
    if (n < 2) return;
    const uint8_t op = p[0], axisId = p[1];
    if (op == M_STATUS) { printStatus(out); return; }
    if (axisId == 0 && (op == M_HOLD || op == M_RELEASE)) {
      act(yaw, op, 0, false); act(tilt, op, 0, false); act(body, op, 0, false); printStatus(out); return;
    }
    MotorAxis* a = axisId == MOTOR_YAW ? &yaw : axisId == MOTOR_TILT ? &tilt : axisId == MOTOR_BODY ? &body : nullptr;
    if (!a) return;
    int16_t centiDeg = 0;
    bool follow = false;
    if (op == M_GOAL) {
      if (n < 5) return;
      centiDeg = (int16_t)(((uint16_t)p[2] << 8) | p[3]);
      follow = p[4] != 0;
    }
    act(*a, op, centiDeg / 100.0f, follow);
    // Goals are a streaming path; periodic polling and M_STATUS supply telemetry.
    // Do not multiply bus reads and WebSocket replies by the goal frame rate.
    if (op == M_GOAL) return;
    poll(*a);
    printOne(*a, out);
  }

  void holdAll() { act(yaw, M_HOLD, 0, false); act(tilt, M_HOLD, 0, false); act(body, M_HOLD, 0, false); }

  void printStatus(Print& out = Serial) {
    printScan(out);
    poll(yaw); poll(tilt); poll(body);
    printOne(yaw, out); printOne(tilt, out); printOne(body, out);
  }

 private:
  Dynamixel2Arduino dxl;
  DYNAMIXEL::InfoFromPing_t scanInfo[16];
  uint8_t scanCount = 0;
  MotorAxis yaw, tilt, body;
  int32_t yawCenterRaw = -576; // measured physical front, torque off, 2026-10-31
  int32_t bodyCenterRaw = 2344; // measured physical front, torque off, 2026-10-31
  uint32_t lastPollMs = 0;

  void printScan(Print& out) {
    out.print(F("DXL_SCAN count=")); out.println(scanCount);
    for (uint8_t i = 0; i < scanCount; i++) {
      out.print(F("DXL_FOUND id=")); out.print(scanInfo[i].id);
      out.print(F(" model=")); out.print(scanInfo[i].model_number);
      out.print(F(" firmware=")); out.print(scanInfo[i].firmware_version);
      const float raw = dxl.getPresentPosition(scanInfo[i].id, UNIT_RAW);
      out.print(F(" raw="));
      if (isfinite(raw)) out.print(lroundf(raw)); else out.print(F("ERR"));
      out.print(F(" torque="));
      out.println((int32_t)dxl.readControlTableItem(TORQUE_ENABLE, scanInfo[i].id) == 1 ? 1 : 0);
    }
  }

  int32_t readItem(uint8_t item, uint8_t id) { return (int32_t)dxl.readControlTableItem(item, id); }

  void discover(MotorAxis& a) {
    a.found = dxl.ping(a.id);
    if (!a.found) return;
    // First action after every successful ping is release. Never retain torque across an Arduino reset.
    dxl.torqueOff(a.id);
    a.torque = false;
    if (COMMISSIONING_LOCK || !a.calibrated) a.fault = MF_CALIBRATION;
    poll(a);
  }

  void torqueOff(MotorAxis& a) {
    a.following = false;
    if (a.found) dxl.torqueOff(a.id);
    a.torque = false;
    if (COMMISSIONING_LOCK) a.fault = MF_CALIBRATION;
  }

  int32_t toRaw(const MotorAxis& a, float deg) const {
    if (a.id == MOTOR_YAW) return lroundf(yawCenterRaw + deg * 71.6556f);
    if (a.id == MOTOR_BODY) return lroundf(bodyCenterRaw + deg * 40.0611f);
    return deg >= 0 ? lroundf(2061.0f - deg * (220.0f / 15.0f))
                    : lroundf(2061.0f + (-deg) * (194.0f / 15.0f));
  }

  float toDeg(const MotorAxis& a, int32_t raw) const {
    if (a.id == MOTOR_YAW) return (raw - yawCenterRaw) / 71.6556f;
    if (a.id == MOTOR_BODY) return (raw - bodyCenterRaw) / 40.0611f;
    return raw <= 2061 ? (2061 - raw) * (15.0f / 220.0f)
                       : -(raw - 2061) * (15.0f / 194.0f);
  }

  bool writeItem(uint8_t item, uint8_t id, int32_t value) {
    if (!dxl.writeControlTableItem(item, id, value)) return false;
    return true;
  }

  void poll(MotorAxis& a) {
    if (!a.found) { discover(a); return; }
    const float raw = dxl.getPresentPosition(a.id, UNIT_RAW);
    if (!isfinite(raw) || dxl.getLastLibErrCode() != DXL_LIB_OK) { a.found = false; a.fault = MF_COMM; return; }
    a.presentRaw = lroundf(raw);
    a.presentDeg = toDeg(a, a.presentRaw);
    a.torque = readItem(TORQUE_ENABLE, a.id) == 1;
    a.mode = (uint8_t)readItem(OPERATING_MODE, a.id);
    a.hwError = (uint8_t)readItem(HARDWARE_ERROR_STATUS, a.id);
    const int32_t pv = readItem(PROFILE_VELOCITY, a.id);
    a.profileOk = pv > 0 && (uint32_t)pv <= a.profileVel;
    if (a.hwError) { a.fault = MF_HARDWARE; safeHold(a); }
  }

  bool prepareAndArm(MotorAxis& a) {
    if (COMMISSIONING_LOCK) { torqueOff(a); return false; }
    if (!a.found || a.fault) return false;
    if (!a.calibrated) { a.fault = MF_CALIBRATION; return false; }
    if (a.needsFront) { a.fault = MF_FRONT; return false; }
    if (!a.torque) {
      dxl.torqueOff(a.id);
      if (!dxl.setOperatingMode(a.id, OP_EXTENDED_POSITION)) { a.fault = MF_COMM; return false; }
      if (readItem(OPERATING_MODE, a.id) != 4) { a.fault = MF_PROFILE; return false; }
    } else if (readItem(OPERATING_MODE, a.id) != 4) {
      a.fault = MF_PROFILE; return false;
    }
    if (!writeItem(PROFILE_ACCELERATION, a.id, a.profileAcc) ||
        !writeItem(PROFILE_VELOCITY, a.id, a.profileVel)) { a.fault = MF_COMM; return false; }
    const int32_t readVel = readItem(PROFILE_VELOCITY, a.id);
    if (readVel <= 0 || (uint32_t)readVel > a.profileVel ||
        (uint32_t)readItem(PROFILE_ACCELERATION, a.id) != a.profileAcc) { a.fault = MF_PROFILE; return false; }
    const float hereF = dxl.getPresentPosition(a.id, UNIT_RAW);
    if (!isfinite(hereF) || dxl.getLastLibErrCode() != DXL_LIB_OK) { a.fault = MF_COMM; return false; }
    const int32_t here = lroundf(hereF);
    if (!dxl.setGoalPosition(a.id, here, UNIT_RAW)) { a.fault = MF_COMM; return false; }
    if (readItem(GOAL_POSITION, a.id) != here) { a.fault = MF_COMM; return false; }
    delay(20);
    const float verifyF = dxl.getPresentPosition(a.id, UNIT_RAW);
    if (!isfinite(verifyF) || dxl.getLastLibErrCode() != DXL_LIB_OK || abs(lroundf(verifyF) - here) > 4) { a.fault = MF_COMM; return false; }
    if (readItem(HARDWARE_ERROR_STATUS, a.id) != 0) { a.fault = MF_HARDWARE; return false; }
    if (!dxl.torqueOn(a.id)) { a.fault = MF_COMM; return false; }
    if (readItem(TORQUE_ENABLE, a.id) != 1) { a.fault = MF_COMM; return false; }
    a.torque = true; a.profileOk = true; a.goalRaw = here; a.goalDeg = toDeg(a, here);
    return true;
  }

  void safeHold(MotorAxis& a) {
    a.following = false;
    if (!a.found || !a.torque) return;
    const int32_t here = lroundf(dxl.getPresentPosition(a.id, UNIT_RAW));
    dxl.setGoalPosition(a.id, here, UNIT_RAW);
    a.goalRaw = here; a.goalDeg = toDeg(a, here);
  }

  void act(MotorAxis& a, uint8_t op, float deg, bool follow) {
    if (!a.found && op != M_CLEAR) { a.fault = MF_COMM; return; }
    if (op == M_CLEAR) {
      poll(a);
      if (COMMISSIONING_LOCK || !a.calibrated) { torqueOff(a); a.fault = MF_CALIBRATION; }
      else if (!a.hwError) a.fault = MF_NONE;
      return;
    }
    if (op == M_RELEASE) {
      a.following = false;
      if (a.found) dxl.torqueOff(a.id);
      a.torque = false;
      return;
    }
    if (op == M_HOLD) { safeHold(a); return; }
    if (op == M_SETUP_FRONT) {
      if (COMMISSIONING_LOCK) { torqueOff(a); return; }
      if (a.id != MOTOR_YAW && a.id != MOTOR_BODY) { a.fault = MF_CALIBRATION; return; }
      const float raw = dxl.getPresentPosition(a.id, UNIT_RAW);
      if (!isfinite(raw) || dxl.getLastLibErrCode() != DXL_LIB_OK) { a.fault = MF_COMM; return; }
      if (a.id == MOTOR_YAW) yawCenterRaw = lroundf(raw);
      else bodyCenterRaw = lroundf(raw);
      a.needsFront = false;
      a.fault = MF_NONE;
      prepareAndArm(a);
      return;
    }
    if (op == M_ARM) { prepareAndArm(a); return; }
    if (COMMISSIONING_LOCK) { torqueOff(a); return; }
    if (op != M_GOAL || a.fault || !a.torque || !a.profileOk || a.needsFront) return;
    if (deg < -a.limitDeg || deg > a.limitDeg) { a.fault = MF_RANGE; safeHold(a); return; }
    const int32_t raw = toRaw(a, deg);
    if (!dxl.setGoalPosition(a.id, raw, UNIT_RAW)) { a.fault = MF_COMM; safeHold(a); return; }
    a.goalRaw = raw; a.goalDeg = deg; a.following = follow; a.lastGoalMs = millis();
  }

  void watchdog(MotorAxis& a, uint32_t now) {
    if (!a.found || !a.torque || !a.following) return;
    if (now - a.lastGoalMs > MOTOR_WATCHDOG_MS) { safeHold(a); return; }
    if (fabsf(a.goalDeg - a.presentDeg) > TRACK_ERROR_DEG) {
      a.fault = MF_TRACKING;
      safeHold(a);
    }
  }

  void printOne(const MotorAxis& a, Print& out) {
    out.print(F("MOTOR axis=")); out.print(a.name);
    out.print(F(" found=")); out.print(a.found ? 1 : 0);
    out.print(F(" torque=")); out.print(a.torque ? 1 : 0);
    out.print(F(" mode=")); out.print(a.mode);
    out.print(F(" profile=")); out.print(a.profileOk ? 1 : 0);
    out.print(F(" deg=")); out.print(a.presentDeg, 2);
    out.print(F(" raw=")); out.print(a.presentRaw);
    out.print(F(" hw=")); out.print(a.hwError);
    out.print(F(" fault=")); out.print(a.fault);
    out.print(F(" front=")); out.print(a.needsFront ? 0 : 1);
    out.print(F(" limit=")); out.print(a.limitDeg, 1);
    out.println();
  }
};
