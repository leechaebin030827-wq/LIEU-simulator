#pragma once

// Copy to arduino_secrets.h and fill locally. Never commit the real password.
#define LIEU_WIFI_SSID "YOUR_WIFI_NAME"
#define LIEU_WIFI_PASS "YOUR_WIFI_PASSWORD"
