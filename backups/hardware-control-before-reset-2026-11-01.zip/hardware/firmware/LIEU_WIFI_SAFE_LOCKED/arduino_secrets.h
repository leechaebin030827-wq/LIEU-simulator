#pragma once

#define LIEU_WIFI_SSID "HIDELAB_ROBOWORLD"
#define LIEU_WIFI_PASS "hide1234"
