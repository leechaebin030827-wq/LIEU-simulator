#include <cassert>
#include <iostream>
#include SHIELD_HEADER

int main() {
  LieuMotorShield shield;
  Print out;
  shield.begin();
  assert(FakeBus::arms == 0);
  for (uint8_t axis = 1; axis <= 3; ++axis) {
    const uint8_t setup[] = {M_SETUP_FRONT, axis};
    shield.command(setup, sizeof(setup), out);
  }
  assert(FakeBus::arms == (COMMISSIONING_LOCK ? 0 : 3));
  const int initialGoals = FakeBus::goals;
  FakeBus::reads = 0; out.text.clear();
  // A full second of three-axis, 30-Hz streaming must not create 450 extra
  // register reads or 90 status replies on the same control channel.
  for (int frame = 0; frame < 30; ++frame) {
    for (uint8_t axis = 1; axis <= 3; ++axis) {
      const uint8_t goal[] = {M_GOAL, axis, 0, 0, 1};
      shield.command(goal, sizeof(goal), out);
    }
  }
  assert(FakeBus::reads == 0);
  assert(out.text.empty());
  assert(FakeBus::goals - initialGoals == (COMMISSIONING_LOCK ? 0 : 90));
  fakeNow += 250; shield.tick();
  assert(FakeBus::reads >= 15); // safety telemetry still polls every axis
  const uint8_t status[] = {M_STATUS, MOTOR_TILT};
  shield.command(status, sizeof(status), out);
  assert(out.text.find("MOTOR axis=tilt") != std::string::npos);
  if (!COMMISSIONING_LOCK) {
    // The existing silence watchdog still holds all three followers.
    const int beforeHold = FakeBus::goals;
    fakeNow += 700; shield.tick();
    assert(FakeBus::goals == beforeHold + 3);
    const uint8_t invalid[] = {M_GOAL, MOTOR_TILT, 0x05, 0x78, 1}; // 14 degrees > 13
    shield.command(invalid, sizeof(invalid), out);
    out.text.clear(); shield.command(status, sizeof(status), out);
    assert(out.text.find("fault=3") != std::string::npos);
    const uint8_t release[] = {M_RELEASE, MOTOR_YAW};
    out.text.clear(); shield.command(release, sizeof(release), out);
    assert(out.text.find("torque=0") != std::string::npos);
    const int releasedGoals = FakeBus::goals;
    const uint8_t goal[] = {M_GOAL, MOTOR_YAW, 0, 0, 1};
    shield.command(goal, sizeof(goal), out);
    assert(FakeBus::goals == releasedGoals);
  }
  std::cout << "PASS: streaming bus budget, telemetry, commissioning lock, watchdog and range guard\n";
}
