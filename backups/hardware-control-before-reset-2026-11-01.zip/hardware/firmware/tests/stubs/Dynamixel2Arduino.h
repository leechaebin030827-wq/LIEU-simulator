#pragma once
// Host-only protocol test double. Never used by Arduino sketch builds.
#include <array>
#include <cmath>
#include <cstdint>
#include <sstream>
#include <string>
using std::isfinite;
#define F(value) value
inline uint32_t fakeNow = 0;
inline uint32_t millis() { return fakeNow; }
inline void delay(uint32_t ms) { fakeNow += ms; }
class Print {
 public:
  std::string text;
  template<class T> void print(T value) { std::ostringstream s; s << +value; text += s.str(); }
  void print(const char* value) { text += value; }
  template<class T> void print(T value, int) { print(value); }
  template<class T> void println(T value) { print(value); text += '\n'; }
  void println() { text += '\n'; }
};
inline Print Serial;
inline int Serial1 = 1;
namespace ControlTableItem {
enum : uint8_t { TORQUE_ENABLE, OPERATING_MODE, HARDWARE_ERROR_STATUS, PROFILE_VELOCITY, PROFILE_ACCELERATION, GOAL_POSITION };
}
namespace DYNAMIXEL {
struct InfoFromPing_t { uint8_t id; uint16_t model_number; uint8_t firmware_version; };
}
constexpr uint8_t DXL_BROADCAST_ID = 254, OP_EXTENDED_POSITION = 4, UNIT_RAW = 0, DXL_LIB_OK = 0;
namespace FakeBus {
inline int reads = 0, goals = 0, arms = 0;
inline std::array<int32_t, 5> position = {0, -709, 2055, 2524, 0};
inline std::array<std::array<int32_t, 6>, 5> registers{};
}
class Dynamixel2Arduino {
 public:
  Dynamixel2Arduino(int, uint8_t) {}
  void begin(uint32_t) {}
  void setPortProtocolVersion(float) {}
  bool ping(uint8_t id) { return id >= 1 && id <= 3; }
  uint8_t ping(uint8_t, DYNAMIXEL::InfoFromPing_t* out, size_t) {
    for (uint8_t i = 0; i < 3; ++i) out[i] = {uint8_t(i + 1), 1000, 1};
    return 3;
  }
  bool torqueOff(uint8_t id) {
    if (id < 5) FakeBus::registers[id][ControlTableItem::TORQUE_ENABLE] = 0;
    else for (auto& r : FakeBus::registers) r[ControlTableItem::TORQUE_ENABLE] = 0;
    return true;
  }
  bool torqueOn(uint8_t id) { ++FakeBus::arms; FakeBus::registers[id][ControlTableItem::TORQUE_ENABLE] = 1; return true; }
  bool setOperatingMode(uint8_t id, uint8_t mode) { FakeBus::registers[id][ControlTableItem::OPERATING_MODE] = mode; return true; }
  int32_t readControlTableItem(uint8_t item, uint8_t id) { ++FakeBus::reads; return FakeBus::registers[id][item]; }
  bool writeControlTableItem(uint8_t item, uint8_t id, int32_t value) { FakeBus::registers[id][item] = value; return true; }
  float getPresentPosition(uint8_t id, uint8_t) { ++FakeBus::reads; return FakeBus::position[id]; }
  uint8_t getLastLibErrCode() { return DXL_LIB_OK; }
  bool setGoalPosition(uint8_t id, int32_t value, uint8_t) { ++FakeBus::goals; FakeBus::registers[id][ControlTableItem::GOAL_POSITION] = value; return true; }
};
