# LIEU hardware (UNO R4 + ROBOTIS DYNAMIXEL Shield)

시뮬레이터의 시퀀스를 **실제 눈 매트릭스 2개 + 링 LED 24개 + DYNAMIXEL Yaw/Tilt/Body 모터 3개**로 재생합니다. Body는 로봇 전체를 원기둥축 기준 ±180° 회전시키는 축입니다. Chrome/Edge의 Web Serial 한 연결이 UNO R4로 들어가며, R4의 USB `Serial`은 호스트 통신, `Serial1`은 쉴드의 DYNAMIXEL 버스로 분리됩니다.

```
브라우저 evaluate(sequence, t)
   │ Web Serial: 눈/링 frame + 안전 제한된 motor goal
   ▼
UNO R4 firmware ─┬─ I2C A4/A5 → 눈 2개
                 ├─ D6 → RGBW 링 24개
                 └─ Serial1 D0/D1 + DIR D2 → ROBOTIS DYNAMIXEL Shield → ID 1/2/3
```

`hardware/pi`와 구운 `hardware/frames`는 헤드리스/레거시 재생용으로 남겨 둡니다. 웹 최종 시뮬레이션은 Python/U2D2 브리지를 실행하지 않습니다.

## 배선
| 부품 | UNO R4 | 라즈베리파이 |
|---|---|---|
| 눈 ×2 SDA / SCL | A4 / A5 (같은 선에 병렬) | GPIO2(핀3) / GPIO3(핀5) |
| 눈 VCC / GND | 5V / GND | 5V(핀2·4) / GND(핀6) |
| 링 DIN | D6 (330Ω 직렬) | GPIO18(핀12) |
| 링 5V / GND | 5V(밝기 낮게) / GND | 외부 5V 2A, GND는 Pi와 공통 |
| DYNAMIXEL Shield UART | D0(RX) / D1(TX) | — |
| DYNAMIXEL Shield DIR | D2 | — |
| 모터 버스 | ID 1=Yaw, ID 2=Tilt, ID 3=Body, Protocol 2.0, 115200 baud | — |

주의: 두 눈 보드는 **I²C 주소가 달라야** 합니다(보드의 A0/A1/A2 패드). 기본 가정은 `0x70`(왼쪽)/`0x71`(오른쪽)이며 `python -m lieu_hw info`가 실제 감지된 주소를 출력합니다. 링은 UNO USB 전원에서는 `max_scale 0.25`, `budget_ma 400`으로 제한됩니다(링 전류는 코드에서 추정해 초과 시 자동으로 낮춤). 외부 5V 2A로 옮기면 `hardware.json`에서 올리세요.

## UNO R4 테스트 순서
1. Arduino IDE 라이브러리 관리자에서 **Adafruit NeoPixel**, **Dynamixel2Arduino 0.8.1 이상**, **WebSockets 2.7.2 이상**을 설치합니다. UNO R4 빌드 수정이 포함된 버전이 필요합니다.
2. 쉴드 전원을 모터 정격에 맞는 **별도 전원**으로 공급하고 극성을 확인합니다. USB 5V로 모터를 구동하지 마세요. 쉴드 UART 선택은 D0/D1 하드웨어 UART 경로를 사용합니다.
3. `firmware/lieu_uno_r4/lieu_uno_r4.ino`를 UNO R4 Minima 또는 WiFi에 업로드합니다. 부팅 직후 링 LED0과 눈 중앙 점이 0.4초 켜지면 출력 배선이 확인됩니다.
4. `npm run dev` 후 Chrome/Edge에서 `http://localhost:5173`을 열고 `하드웨어 → 출력 활성화 → Connect Arduino`를 누릅니다. 같은 연결에서 눈·링과 모터 ID 1/2/3 상태가 표시됩니다.
5. Yaw는 전원을 켤 때마다 손으로 정면을 맞춘 뒤 `정면을 맞췄어요 · 시작`을 눌러야 합니다. Tilt는 바로 Arm할 수 있습니다. Body(ID 3)는 `motor_limits.json`의 세 점(-180/0/+180) raw와 안전 속도·가속도가 채워지기 전까지 Arm할 수 없습니다.

## UNO R4 WiFi 무선 제어
1. `arduino_secrets.example.h`를 `arduino_secrets.h`로 복사하고 2.4 GHz SSID/비밀번호를 채웁니다. 실제 파일은 `.gitignore`에 포함되어 Git으로 올라가지 않습니다.
2. 펌웨어 업로드 뒤 USB Serial Monitor(115200 baud)에서 `WIFI READY ... ip=... websocket_port=81`을 확인합니다.
3. 제어 컴퓨터를 같은 Wi-Fi에 연결하고 웹 앱의 `하드웨어 → Arduino IP → Wi-Fi 연결`에 출력된 IP를 입력합니다.
4. 무선 연결이 끊기면 펌웨어가 모터를 Hold하고 눈·링을 Blank합니다. 동시에 한 제어기만 접속할 수 있으며 USB 제어는 비상/점검용으로 계속 사용할 수 있습니다.

UNO R4 WiFi의 무선 모듈은 **2.4 GHz Wi-Fi만 지원**합니다. 5 GHz 전용 SSID에는 연결되지 않습니다.

레거시 Python 장비 확인과 보정:
   ```
   python -m lieu_hw info          # 감지된 I²C 주소 / 눈 보드 유무
   python -m lieu_hw test eyes     # 점 하나가 8×8을 훑음 → 실제 보드에서 위치/방향 확인
   python -m lieu_hw test ring     # LED0 빨강 + 흰 점 이동, 이어 R/G/B/W 색 순서 확인
   ```
   `test eyes`에서 방향이 틀리면 `eyes.*.layout`(`adafruit`/`msb_left`/`lsb_left`), `flip_x`, `flip_y`, `swap`을 고칩니다. 링은 `ring.offset`, `ring.reverse`(LED0 위치/방향), 색 순서는 `.ino`의 `LED_TYPE`을 맞추세요.
6. 헤드리스 재생이 필요할 때만 `python -m lieu_hw play 05_web_cover`를 사용합니다. 장비 없이는 `--backend mock`.

시퀀스를 고친 뒤에는 프레임을 다시 굽습니다: `npx vite-node tools/export_hw_frames.ts [id...]`

## 라즈베리파이로 옮길 때
1. `sudo raspi-config` → Interfaces → I2C 켜기, `i2cdetect -y 1`로 두 주소 확인.
2. `pip install smbus2 rpi_ws281x`, `hardware.json`의 `"backend": "pi"`, 같은 `test`로 재확인(rpi_ws281x는 `sudo` 필요, GPIO18 PWM은 3.5mm 오디오 출력과 충돌 → USB/HDMI 오디오 사용).
3. Pi 5는 rpi_ws281x가 동작하지 않으므로 `drivers/pi_direct.py`의 `_open_ring/_write_ring`만 PIO/SPI 방식으로 교체하면 됩니다.
4. 부팅 자동 실행은 systemd로 `python -m lieu_hw play <id> --loop`.

## 검증 상태
- 하드웨어 없이 검증됨: 프레임 굽기, 매핑/전류 제한/패킷 직렬화(`python -m lieu_hw.tests`), mock 재생.
- **실기 확인 필요**: 업로드 후 모터 전원/ID/baud, 회전 방향, HT16K33 행·열, I²C 주소, 링 LED0·색 순서. 최초 검증은 모터 전원 차단 수단에 손을 둔 상태에서 저속으로 진행하세요.
- 모터 안전: 마스터 출력 잠금 → 축별 Arm, goal 범위, non-zero 속도 프로파일, 600 ms follow watchdog, 15° 추종 오류 latch, 하드웨어 오류 latch, Blank/E-STOP의 즉시 Hold가 펌웨어에 있습니다.
- **펌웨어별 보정 잠금**: `firmware/lieu_uno_r4/motor_shield.h`는 `COMMISSIONING_LOCK=false`, `firmware/LIEU_WIFI_SAFE_LOCKED/motor_shield.h`는 `true`입니다. 잠금 버전은 부팅 시 Torque OFF 및 Arm·정면설정·Goal 거부를 적용합니다. 이 값은 2026-10-31 통신 안정화 작업에서 변경하지 않았으며, 현재 보드에 어떤 빌드가 업로드되어 있는지는 별도 확인해야 합니다.

## 연결 장애 확인

- USB는 다른 탭과 Arduino Serial Monitor에서 포트를 닫은 뒤 연결합니다. 앱은 포트 열기뿐 아니라 `READY LIEU-HW` 또는 `INFO LIEU-HW` 응답을 확인한 뒤 연결 성공을 표시합니다.
- 출력 잠금 상태에서도 상태 조회가 가능합니다. 응답 중단·쓰기 시간 초과·USB 분리 시 연결을 정리하고 출력을 다시 잠급니다. 연결 중 취소 후 다시 시도할 수 있습니다.
- Wi-Fi는 WebSocket 열림과 펌웨어 READY를 모두 확인합니다. 송신 버퍼가 밀리면 오래된 목표를 계속 쌓지 않고 연결을 종료합니다.
- 두 펌웨어는 Wi-Fi 연결 대기 중 USB 처리를 막던 WiFiS3의 기본 10초 association 대기를 제거하고, 연결 상태를 500 ms 간격으로 확인합니다. 무선 모듈 자체 AT 명령의 응답 지연까지 제거하는 변경은 아닙니다.
- `npm run check`는 장치 모의 테스트를 포함합니다. 실제 USB/Wi-Fi 통신과 모터 동작 검증을 대신하지 않습니다.
- 2026-10-31 실물 점검에서는 RESET·USB 재삽입으로 풀리지 않던 통신 정지가 외부 전원과 USB를 모두 분리한 완전 전원 차단 후 복구됐습니다. 수정 펌웨어 업로드 후 USB 3회, Wi-Fi 10초씩 3회 반복 연결과 앱의 실제 Wi-Fi 연결을 확인했습니다. INFO 조회에서 현재 Wi-Fi IP도 확인할 수 있습니다. 모터 전원은 끈 상태로 검사했으므로 실제 가동 검증은 별도입니다.
